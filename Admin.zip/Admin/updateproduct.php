<?php 
    include("adminnavbar.php");
    include("database.php");
    $iname = $price = $category = $description = "";
    $mimg = $miname = $mprice = $mcategory = $mdescription = "";
    $error=0;

    $id = $_GET['id'];

    $sql = "select * from addproduct where id = $id";
    $result = mysqli_query($conn,$sql);
    $r = mysqli_fetch_assoc($result);

    $sqlcate = "select * from category";
    $resultcate = mysqli_query($conn,$sqlcate);
   
    if (isset($_POST["update"])) {
        
        $files = $_FILES["file"];
        $img = $_FILES["file"]["name"];
        $path = "C:/wamp64/www/cake/admin/images/addcake/" . $_FILES["file"]["name"];
        $iname = $_POST["cakename"];
        $price = $_POST["price"];
        $category = $_POST["category"];
        $qty=$_POST["qty"];
        $description = $_POST["description"];
       

    if($iname=="")
    {
        $miname = "Please Enter the Cake Name !!";
        $error++;
    }
    if($price=="")
    {
        $mprice = "Please Enter the Price !!";
        $error++;
    }
    if($category=="")
    {
        $mcategory = "Please Select the Category !!";
        $error++;
    }
    if($description=="")
    {
        $mdescription = "Please Enter Description !!";
        $error++;
    }

        if($error==0)
        {
            
            if(!empty($img)){
                move_uploaded_file($_FILES["file"]["tmp_name"], $path);
                $img= $_FILES["file"]["name"];
            }
            else{
                $img=$r['image'];
            }
        //move_uploaded_file($_FILES["file"]["tmp_name"], $path);

            $sql = "update addproduct set image = '$img',iname = '$iname',price = '$price',category = '$category',qty='$qty',description = '$description' where id = $id";
            $result = mysqli_query($conn, $sql);
            if ($result) {
                ?>
                <script>
                    alert("Product Updated Successfully !!w");
                    location.href="manageproduct.php";
                </script>
                <?php 
            } 
            else 
            {
                echo "<script>";
                echo "alert('Unsuccessfull')";
                echo "</script>";
            }
        }
    }
?>
<html>
<head>
    <title>Update Cake</title>
    <link rel="stylesheet" href="css/addcake.css">
</head>
<body>
    <form method="post" enctype="multipart/form-data">
        <center>
            <div class="addcakemain">
                <label class="addcakeheading">Update Product</label><br>
                
                <img src="<?php echo 'images/addproduct/'.$r['image']; ?>" height="100px" width="100px"><br>
                <?php echo $r['image']; ?><br>                

                <input type="file" name="file" class="acakeinput" ><br>
                <label class="red"><?php echo $mimg; ?></label><br>

                <label class="addcaketextboxuptext">Product ID</label><br>
                <input type="text" class="acakeinput" value="<?php echo $r['id']; ?>" readonly><br>
                <label class="green">You can not change the ID.</label><br>

                <label class="addcaketextboxuptext">Product Name<b class="red">*</b></label><br>
                <input type="text" name="cakename" placeholder="Enter Cake name" class="acakeinput" value="<?php echo $r['iname']; ?>"><br>
                <label class="red"><?php echo $miname; ?></label><br>

                <label class="addcaketextboxuptext">Price<b class="red">*</b></label><br>
                <input type="text" name="price" placeholder="Enter the Price" class="acakeinput" value="<?php echo $r['price']; ?>"><br>
                <label class="red"><?php echo $mprice; ?></label><br>

                

                <label class="addcaketextboxuptext">Category<b class="red">*</b></label><br>
       
                <Select class="acakeinput" name="category" >
                

                <?php  while($rcate = mysqli_fetch_assoc($resultcate))
                {
                    if($rcate['category']==$r['name'])
                    {
                        ?>
                        <option selected value="<?php echo $r['category']; ?>"><?php echo $r['category']; ?></option>
                        <?php
                    }
                    else{
                ?>
                <option value="<?php echo $rcate['category']; ?>"><?php echo $rcate['category']; ?></option>
                <?php
                    }
                }
                ?>
                </Select><br>
                <label class="red"><?php echo $mcategory; ?></label><br>

                <label class="addcaketextboxuptext">Quantity<b class="red">*</b></label><br>
                <input type="text" name="qty" placeholder="Enter the Price" class="acakeinput" value="<?php echo $r['qty']; ?>"><br>
                <label class="red"><?php echo $mprice; ?></label><br>


                <label class="addcaketextboxuptext">Description<b class="red">*</b></label><br>
                <textarea name="description" placeholder="Enter description about Cake" class="acaketextarea" ><?php echo $r['description']; ?></textarea><br>
                <label class="red"><?php echo $mdescription; ?></label><br>

                <center>
                    <input type="Submit" name="update" value="Modify" class="upload">
                </center>
                
            </div>
        </center>
    </form>
</body>
</html>
<script src="javascript/addcake.js"></script>