<?php include("adminnavbar.php")?>
<?php
error_reporting(0);
    include("database.php");

    session_start();

    if(!$_SESSION['adusername'])
    {
        ?>
        <script>
            alert("First you have to Login !!");
            location.href = "index.php";
        </script>
        <?php
    }
    if(isset($_POST["sub"]))
    {
        echo "ok";
        $files = $_FILES["file"];
        echo $img = $_FILES["file"]["name"];
        $catname = $_POST["catname"];
        echo $path = "C:/xampp/htdocs/MY PROJECT/Admin/images/category/".$img;

        if(move_uploaded_file($_FILES["file"]["tmp_name"],$path))
        {
            echo "move";
        }
        $sql = "insert into category values(id,'$img','$catname')";
        $result = mysqli_query($conn,$sql);
    }
?>
<html>
<head>
    <title>Add stock</title>
    
    <link rel="stylesheet" href="css/addcatagory.css">
</head>
<body>
<form method="post" enctype="multipart/form-data">
    <center>
    <div class="addcakemain">
    <label class="addcakeheading">Add stock</label><br>

    <label class="addcaketextboxuptext">Product Name<b class="red">*</b></label><br>
                <Select class="acakeinput" name="category">
                    <option selected disabled>Select</option>
                <?php
                    while($rowct = mysqli_fetch_assoc($resultct))
                    {
                        ?>
                        <option value="<?php echo $rowct['name']; ?>"><?php echo $rowct["name"]; ?></option>
                        <?php
                    }
                ?>
                </Select><br>
        <br>
        Add Quentity: <br>
        <input type="text" name="catname" class="acakeinput"><br><br>

        <center><input type="Submit" name="sub" value="Submit" class="upload"></center>
    </div>
        </center>
    </form>
</body>
</html>