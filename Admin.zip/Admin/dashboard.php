<?php
    include("database.php");
    $sql = "select * from category";
    $result = mysqli_query($conn,$sql);
?>
<html lang="en">
<head>
    <title>Dashboard</title>
</head>
<body>
    <?php

    ?>
    <h1>Dashboard</h1>
    <center>
    <br>50
    <h3>Categories</h3>
    </center>
</body>
</html>