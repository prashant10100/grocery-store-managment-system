<html>

<head>
    <link rel="stylesheet" href="css/navigation.css">
    </link>
</head>

<body class="adwelbody">
    <div class="logoandpanelflex">
        <img src="images/4.png" height=80px width="100px" alt="">
        <div class="adnav">

            <div>
                <a href="admindashbord.php" class="menutext">Dashboard</a>
            </div>
            <div>
                <a class="menutext" href="manageorders.php">Order</a>
            </div>
            <!-- <div>
                <a class="menutext">Stock</a>
                <div class="adnavdd">
                    <div class="navddp1">
                        <a href="addstock.php" class="ddtextlink"><label>Add Stock</label></a><br>
                        <a href="managestock.php" class="ddtextlink"><label class="dropdowntext">Manage
                        Stock</label></a>
                    </div>
                </div>
            </div> -->
            <div>
                <a class="menutext">Categories</a>
                <div class="adnavdd">
                    <div class="navddp1">
                        <a href="addcategory.php" class="ddtextlink"><label>Add Category</label></a><br>
                        <a href="managecatagory.php" class="ddtextlink"><label class="dropdowntext">Manage
                                Category</label></a>
                    </div>
                </div>
            </div>
            <div>
                <a class="menutext">Product</a>
                <div class="adnavdd">
                    <div class="navddp1">
                        <a href="addproduct.php" class="ddtextlink">Add Product</a><br>
                        <a href="manageproduct.php" class="ddtextlink">Manage Product</a>
                    </div>
                </div>
            </div>
            <div>
                <a href="registeruser.php" class="menutext">Register Users</a>
            </div>
            <div>
                <a href="logout.php" class="menutext">Logout</a>
            </div>
        </div>
    </div>
</body>

</html>