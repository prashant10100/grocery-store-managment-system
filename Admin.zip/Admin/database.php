<?php
    $conn = mysqli_connect("localhost", "root", "", "onlinegrocery");
    if($conn)
    {
        echo " ";
    }
    ?>
    