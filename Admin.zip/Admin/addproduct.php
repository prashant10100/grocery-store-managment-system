<?php
include("adminnavbar.php");
include("database.php");

session_start();

    if(!$_SESSION['adusername'])
    {
        ?>
        <script>
            alert("First you have to Login !!");
            location.href = "index.php";
        </script>
        <?php
    }

$iname = $price = $qty = $category = $description = "";
$mimg = $miname = $mprice = $mqty = $mcategory = $mdescription = "";
$error=0;
    $sqlct = "select * from category";
    $resultct = mysqli_query($conn, $sqlct);
    
if (isset($_POST["upload"])) {
    $files = $_FILES["file"];
    $img = $_FILES["file"]["name"];
    $path = "C:\Users\dell\Desktop\MY PROJECT\Admin\images\addproduct/" . $_FILES["file"]["name"];
    $iname = $_POST["cakename"];
    $price = $_POST["price"];
    $qty = $_POST["qty"];
    $category = $_POST["category"];
    $description = $_POST["description"];

    if($img=="")
    {
        $mimg = "Please Select Image !!";
        $error++;
    }
    if($iname=="")
    {
        $miname = "Please Enter the Cake Name !!";
        $error++;
    }
    if($price=="")
    {
        $mprice = "Please Enter the Price !!";
        $error++;
    }
    if($qty=="")
    {
        $mqty = "Please Enter the Quantity !!";
        $error++;
    }
    if($category=="")
    {
        $mcategory = "Please Select the Category !!";
        $error++;
    }
    if($description=="")
    {
        $mdescription = "Please Enter Description !!";
        $error++;
    }

    if($error==0)
    {
        move_uploaded_file($_FILES["file"]["tmp_name"], $path);

        $sql = "insert into addproduct values(id,'$img','$iname','$price',$qty,'$category','$description')";
        $result = mysqli_query($conn, $sql);
        if ($result) {
        ?>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    Swal.fire({
        title: "Product has been added successfully!",
        icon: "success",
        draggable: true
    }).then(() => {
        location.href = "manageproduct.php";
    });
</script>

        <?php    
        
        } else {
            echo "<script>";
            echo "alert('Unsuccessfull')";
            echo "</script>";
        }
    }
}
?>
<html>

<head>
    <title>Add Product</title>
    <link rel="stylesheet" href="css/addproduct.css">
</head>

<body>
    <form method="post" enctype="multipart/form-data">
        <center>
            <div class="addcakemain">

                <label class="addcakeheading">Add Product</label><br>

                <label class="addcaketextboxuptext">Choose File<b class="red">*</b></label><br>
                <input type="file" name="file" class="acakeinput"><br>
                <label class="red"><?php echo $mimg; ?></label><br>

                <label class="addcaketextboxuptext">Product Name<b class="red">*</b></label><br>
                <input type="text" name="cakename" placeholder="Enter cake name" class="acakeinput" value="<?php echo $iname; ?>"><br>
                <label class="red"><?php echo $miname; ?></label><br>

                <label class="addcaketextboxuptext">Price<b class="red">*</b></label><br>
                <input type="text" name="price" placeholder="Enter price" class="acakeinput" value="<?php echo $price; ?>"><br>
                <label class="red"><?php echo $mprice; ?></label><br>

                <label class="addcaketextboxuptext">Quantity<b class="red">*</b></label><br>
                <input type="text" name="qty" placeholder="Enter Quantity" class="acakeinput" value="<?php echo $qty; ?>"><br>
                <label class="red"><?php echo $mprice; ?></label><br>

                <label class="addcaketextboxuptext">Category<b class="red">*</b></label><br>
                <Select class="acakeinput" name="category">
                    <option selected disabled>Select</option>
                <?php
                    while($rowct = mysqli_fetch_assoc($resultct))
                    {
                        ?>
                        <option value="<?php echo $rowct['name']; ?>"><?php echo $rowct["name"]; ?></option>
                        <?php
                    }
                ?>
                </Select><br>
                <label class="red"><?php echo $mcategory; ?></label><br>

                <label class="addcaketextboxuptext">Description<b class="red">*</b></label><br>
                <textarea name="description" placeholder="Enter description about Cake" class="acaketextarea" value="<?php echo $description; ?>"></textarea><br>
                <label class="red"><?php echo $mdescription; ?></label><br>

                <center>
                    <input type="Submit" name="upload" value="Upload" class="upload">
                </center>
            </div>
        </center>
    </form>
</body>
</html>
<script src="javascript/addproduct.js"></script>