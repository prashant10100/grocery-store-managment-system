<?php
    include("adminnavigation.php");
    include("database.php");
    echo $id = $_GET["id"];

    $sql = "delete from category where id = $id";
    $result = mysqli_query($conn,$sql);
    if($result)
    {
        header("location:managecatagory.php");
    }
?>