<?php

include("adminnavbar.php");
include("database.php");
session_start();

    if(!$_SESSION['adusername'])
    {
        ?>
        <script>
            alert("First you have to Login !!");
            location.href = "index.php";
        </script>
        <?php
    }

$sql = "select * from addproduct";
$result = mysqli_query($conn,$sql);

?>

<html>
<head>
    <title>Manage Cake</title>
    <link rel="stylesheet" href="css/managecat.css">
</head>
<body>
<center><a href="addproduct.php"><button class="addbuttoninmcake">Add+</button></a>
    <table width="90%">
        <tr>
            <th>ID</th>
            <th>Image</th>
            <th>Product Name</th>
            <th>Price</th>
            <th>Category</th>
            <th>Qty</th>
            
            <th>Description</th>
            <th colspan=2>Actions</th>
        </tr>

    <?php
    while($r = mysqli_fetch_assoc($result))
    {
        ?>
        <tr>
            <td><?php echo $r['id']; ?></td>
            <td><img src="images/addproduct/<?php echo $r['image']; ?>" height="100px" width="100px"></td>
            <td><?php echo $r['iname']; ?></td>
            <td><?php echo $r['price']; ?></td>
            <td><?php echo $r['category']; ?></td>
            <td><?php echo $r['qty']; ?></td>
            <td class="justifytddesc"><?php echo $r['description']; ?></td>
            <td><a href="updateproduct.php?id=<?php echo $r['id']; ?>"><img src="images/edit1.png" height="30px" width="30px" alt="Update"></a></td>
            <td><a href="deleteproduct.php?id=<?php echo $r['id']; ?>"><img src="images/icon1.png" height="30px" width="30px" alt="Delete"></a></td>
        </tr>

        <?php
    }
    ?>
    </table>
    </center>
</body>
</html>
