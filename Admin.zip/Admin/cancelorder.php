<?php
    include("database.php");
    echo $id = $_GET['id'];

    $statusres = mysqli_query($conn,"update orders set order_status = 'Cancel' where id = $id");
    if($statusres)
    {
        ?>
        <script>
            alert("Updated !!");
            location.href = "manageorders.php";
        </script>
        <?php
    }
?>