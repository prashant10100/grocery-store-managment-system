<?php 
    include("database.php");
    include("adminnavbar.php");

    session_start();

    if(!$_SESSION['adusername'])
    {
        ?>
        <script>
            alert("First you have to Login !!");
            location.href = "index.php";
        </script>
        <?php
    }
    

    $sql = "select * from newregistration";
    $result = mysqli_query($conn,$sql);
    $row = mysqli_num_rows($result);
    echo "<table class='regtable'>";
        echo "<tr>";

            echo "<th class='tableheading'>ID";  
            echo "<th class='tableheading'>Image";
            echo "<th class='tableheading'>Name";
            echo "<th class='tableheading'>Mobile No.";
            echo "<th class='tableheading'>DOB";
            echo "<th class='tableheading'>City";
            echo "<th class='tableheading'>Gender";
            echo "<th class='tableheading'>E-mail";
            echo "<th class='tableheading'>Username";
            echo "<th class='tableheading' colspan=2>Action";
        echo "</tr>";
    while($re = mysqli_fetch_assoc($result))
    {
        ?>
                
            <tr class='trreguser'>
                <td class='tdreguser'><?php echo $re['id']; ?>
                <td class='tdreguser'><img src="images\Register User/<?php echo $re['img']; ?>" alt="" class="reguserimage">
                <td class='tdreguser'><?php echo $re['name']; ?>
                <td class='tdreguser'><?php echo $re['mno']; ?>
                <td class='tdreguser'><?php echo $re['dob']; ?>
                <td class='tdreguser'><?php echo $re['city']; ?>
                <td class='tdreguser'><?php echo $re['g']; ?>
                <td class='tdreguser'><?php echo $re['email']; ?>
                <td class='tdreguser'><?php echo $re['username']; ?>
                <td class='tdreguser'><a href="deleteuser.php?id=<?php echo $re['id']; ?>">Delete</a>
                <!-- <td class='tdreguser'><a href="deleteuser.php?id=<?php echo $re['id']; ?>">Delete</a> -->

            </tr>
            <?php
        
    }
    echo "</table>";
?>
<html>
<head>
    <title>Register Users</title>
    <link rel="stylesheet" href="css/registeruser.css">
</head>
<body>
    
</body>
</html>