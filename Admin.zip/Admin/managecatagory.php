
<?php

include("adminnavbar.php");
include("database.php");
session_start();

if(!$_SESSION['adusername'])
{
    ?>
    <script>
        alert("First you have to Login !!");
        location.href = "index.php";
    </script>
    <?php
}
$sql = "select * from category order by id asc";
$result = mysqli_query($conn,$sql);

?>
<html>
<head>
    <title>Manage Category</title>
    <link rel="stylesheet" href="css/managecatogry.css">
</head>
<body>
<center><a href="addcategory.php"><button class="addbuttoninmcake">ADD+</button></a></center>
    <table width="100%">
        <tr>
            <th>ID</th>
            <th>Category Image</th>
            <th>Category Name</th>
            <th colspan=2>Actions</th>
        </tr>

    <?php
    while($r = mysqli_fetch_assoc($result))
    {
        ?>
        <tr>
            <td><?php echo $r['id']; ?></td>
            <td><?php echo $r['image']; ?></td>
            <td><?php echo $r['name']; ?></td>
            <td><a href="updatecatagory.php?id=<?php echo $r['id']; ?>">Update</a></td>
            <td><a href="deletecatagory.php?id=<?php echo $r['id']; ?>">Delete</a></td>
        </tr>

        <?php
    }
    ?>
    </table>    
</body>
</html>
