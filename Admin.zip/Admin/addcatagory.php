<html>
<head>
    <title>Add Category</title>
    <link rel="stylesheet" href="css/addcatagory.css">
</head>

<body>
    <form method="post">
        <center>
            <div class="addcakemain">
                <label class="addcakeheading">Add Category</label><br>

                <label class="addcaketextboxuptext">Category Name<b class="red">*</b></label><br>
                <input type="file" name="file" class="acakeinput"><br>
                <label class="red"></label><br>

                <label class="addcaketextboxuptext">Main Category<b class="red">*</b></label><br>
                <input type="text" name="ctname" placeholder="Enter Category " class="acakeinput"><br>
                <label class="red"></label><br>
                

                <center>
                    <input type="Submit" name="add" value="Add" class="upload">
                </center>
            </div>
        </center>
    </form>
</body>

</html>
<script src="javascript/addcake.js"></script>