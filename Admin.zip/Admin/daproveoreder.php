<?php
error_reporting(0);
session_start();
include("adminnavbar.php");
include("database.php");


if (isset($_GET['delete'])) {
    echo $delete_id = $_GET['delete'];
    $q1 = "DELETE FROM `orders` WHERE id = $delete_id ";
    $result = mysqli_query($conn, $q1);
    if ($result) {
        header('location:daproveoreder.php');
    }
}

?>

<html>

<head>
    <title>Admin Panel</title>
    <link rel="stylesheet" href="css/pendingorder.css">
    <link rel="stylesheet" href="fontawesome-free-6.7.2-web/css/fontawesome.min.css">
    <link rel="stylesheet" href="fontawesome-free-6.7.2-web/css/all.min.css">
</head>

<body>


    <center>
        <p class="message">Approved Orders</p>
        <div class="display">
            <section class="">

                <table>


                    <tbody>
                        <center>
                            <?php
                            $q1 = "SELECT * FROM `orders` where order_status='Approve' ";
                            $result = mysqli_query($conn, $q1);
                            if (mysqli_num_rows($result) > 0) {
                                echo "
                    <tr>
                        <th>User_name</th>
                        <th>Mobile No</th>
                        <th>Email</th>
                        <th>method</th>
                        <th>Address</th>         
                        <th>Total Prodect</th>
                        <th>Total Amount</th>
                        <th>Action</th>
                
                    </tr>";
                                while ($row = mysqli_fetch_assoc($result)) {
                            ?>


                                    <tr>
                                        <td><?php echo $row['id']; ?></td>
                                        <td><?php echo $row['username']; ?></td>
                                        <td><?php echo $row['email']; ?></td>
                                        <td><?php echo $row['method']; ?></td>
                                        <td class="justifytddesc"><?php echo $row['fullAddress'] ?></td>
                                        <td><?php echo $row['p_name']; ?></td>
                                        <td><?php echo $row['p_price']; ?></td>
                                       
                                        <td>
                                            <a title='Delete' href="daproveoreder.php?delete=<?php echo $row['id']; ?>" onclick="return confirm('are your sure you want to delete this?');">Delete</a>
                                        </td>
                                    </tr>
                            <?php
                                }
                            } else {
                                echo "<div class='empty'>Not have any Order Approved</div>";
                            }
                            ?>
                        </center>
                    </tbody>
                </table>

            </section>

        </div>
</body>

</html>