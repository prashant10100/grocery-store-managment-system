<html>

<head>
    <link rel="stylesheet" href="css/navigation.css"></link>
</head>

<body class="adwelbody">
    <div class="adnav">
        <div>
            <a href="admindashboard.php" class="menutext">Dashboard</a>
        </div>
        <div>
            <a class="menutext" href="order.php">Order</a>
        </div>
        <div>
            <a class="menutext" >Categories</a>
            <div class="adnavdd">
                <div class="navddp1">
                    <a href="addcategory.php" class="ddtextlink"><label>Add Category</label></a><br>
                    <a href="managecategory.php" class="ddtextlink"><label class="dropdowntext">Manage Category</label></a>
                </div>
            </div>
        </div>
        <div>
            <a class="menutext">Cakes</a>
            <div class="adnavdd">
                <div class="navddp1">
                    <a href="addcake.php" class="ddtextlink">Add Cake</a><br>
                    <a href="managecake.php" class="ddtextlink">Manage Cake</a>
                </div>
            </div>
        </div>
        <div>
            <a href="registeruser.php" class="menutext">Register Users</a>
        </div>
    </div>
</body>

</html>