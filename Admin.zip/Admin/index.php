
<?php
session_start();		
include("database.php");
		if(isset($_POST['login']))
		{
        $username=$_POST['adusername'];
        $password=$_POST['adpassword'];

        if($username == "prashant" && $password == "12345678")
        {
            echo $_SESSION['adusername'] = $username;
            ?>
            <script>
                alert("You can login successfully !!");
                location.href = "admindashbord.php";
            </script>
            <?php
        }
        }
?>
<html>
<head>
    <title>Admin Login</title>
    <link rel="stylesheet" href="css/login.css"></link>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="adminlogbody">
    <form method="post">
        <div class="adminloginconteiner">
            <label class="alogintext">Admin Login</label><br>

            <label class="loglabeltext">username<b class="red">*</b></label><br>
            <input type="text" name="adusername" placeholder="Enter Admin username" class="loginput"><br>
         
            <br>

            <label class="loglabeltext">Password<b class="red">*</b></label><br>
            <input type="password" name="adpassword" placeholder="Enter Admin Password" class="loginput" id="password"><br>
        

            <!-- <a href="admin_forgotpass.php" class="forgetandsignup">Forget Password?</a><br><br> -->

            <input type="submit" name="login" value="Login" class="loginbutton"><br><br>

            <!-- <center><label class="signuplabeltext">Don't have Account? <a href="admin_signup.php"  class="forgetandsignup">Sign Up</a></label></center> -->
        </div>
    </form>
</body>
</html>
<script src="javascript/adminlogin.js"></script>