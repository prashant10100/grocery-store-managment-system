<?php
include("database.php");
include("adminnavbar.php");

error_reporting(0);
session_start();

    if(!$_SESSION['adusername'])
    {
        ?>
        <script>
            alert("First you have to Login !!");
            location.href = "index.php";
        </script>
        <?php
    }

$sql = "select * from newregistration";
$result = mysqli_query($conn, $sql);
$row = mysqli_num_rows($result);

$sqlct = "select * from category";
$resultct = mysqli_query($conn, $sqlct);
$rowct = mysqli_num_rows($resultct);

$ordercount = mysqli_query($conn,"select * from orders");
$ordertotal = mysqli_num_rows($ordercount);

$productre = mysqli_query($conn,"select * from addproduct");
$countproduct = mysqli_num_rows($productre);

$approveres = mysqli_query($conn,"select * from orders where order_status = 'Approve'");
$approvecount = mysqli_num_rows($approveres);

$cancelres = mysqli_query($conn,"select * from orders where order_status = 'Cancel'");
$cancelcount = mysqli_num_rows($cancelres);

?>
<html>

<head>
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/dashbord.css">
</head>

<body>
    
    <div class="dashflex">
        <div class="registerusercontainer">
            <a href="registeruser.php" class="dashboardlink">
                <label class="dashboardtext"><?php echo $row; ?></label>
                <h2>Register Users</h2>
            </a>
        </div>

        <div class="categorycontainer">
            <a href="managecatagory.php" class="dashboardlink">
                <label class="dashboardtext"><?php echo $rowct; ?></label>
                <h2>Total Category</h2>
            </a>
        </div>

        <div class="ordercontainer">
        <a href="manageorders.php" class="dashboardlink">
                <label class="dashboardtext"><?php echo $ordertotal; ?></label>
                <h2>Total Orders</h2>
            </a>
        </div>

        <div class="ordercontainer1">
            <a href="manageproduct.php" class="dashboardlink1">
                <label class="dashboardtext"><?php echo $countproduct; ?></label>
                <h2>Total Product</h2>
            </a>
        </div>

        <div class="aproveorder">
            <a href="daproveoreder.php" class="dashboardlink1">
                <label class="dashboardtext"><?php echo $approvecount; ?></label>
                <h2>Approved Orders</h2>
            </a>
        </div>

        <div class="cancelorder">
            <a href="dcancel.php" class="dashboardlink1">
                <label class="dashboardtext"><?php echo $cancelcount; ?></label>
                <h2>Cancel Orders</h2>
            </a>
        </div>

    </div>
</body>

</html>