<?php
include("database.php");

$id = $_GET["id"];

$sql = "delete from newregistration where id = $id";
$result = mysqli_query($conn,$sql);
if($result)
{
    header("location:registeruser.php");
}
?>