
<?php

include("adminnavbar.php");
include("database.php");
session_start();

if(!$_SESSION['adusername'])
{
    ?>
    <script>
        alert("First you have to Login !!");
        location.href = "index.php";
    </script>
    <?php
}


$sql = "select * from orders order by id asc";
$result = mysqli_query($conn,$sql);

?>
<html>
<head>
    <title>Manage orders</title>
    <link rel="stylesheet" href="css/managecatogry.css">
</head>
<body>
<!-- <center><a href="addcategory.php"><button class="addbuttoninmcake">ADD+</button></a></center> -->
    <table width="100%">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Number</th>
            <th>Email</th>
            <th>Method</th>
            <th>Full Address</th>
            <th>Product Name</th>
            <th>Quentity</th>
            <th>Product Price</th>
            <th>Grand Total</th>
            <th>Order Status</th>
            <th colspan=2>Actions</th>
        </tr>

    <?php
    while($r = mysqli_fetch_assoc($result))
    {
        ?>
        <tr>
            <td><?php echo $r['id']; ?></td>
            <td><?php echo $r['name']; ?></td>
            <td><?php echo $r['number']; ?></td>
            <td><?php echo $r['email']; ?></td>
            <td><?php echo $r['method']; ?></td>
            <td><?php echo $r['fullAddress']; ?></td>
            <td><?php echo $r['p_name']; ?></td>
            <td><?php echo $r['qty']; ?></td>
            <td><?php echo $r['p_price']; ?></td>
            <td><?php echo $r['g_total']; ?></td>
            <td><?php echo $r['order_status']; ?></td>
            <td><a href="approvedorder.php?id=<?php echo $r['id']; ?>">Aprove</a></td>
            <td><a href="cancelorder.php?id=<?php echo $r['id']; ?>">Cancel</a></td>
        </tr>

        <?php
    }
    ?>
    </table>    
</body>
</html>
