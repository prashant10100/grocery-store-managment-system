let sok = document.querySelector(".successok");
let success = document.querySelector(".success");

sok.onclick = function()
{
    console.log("hellow");
    success.style.display = "none";
    
    location.href="cart.php";
}