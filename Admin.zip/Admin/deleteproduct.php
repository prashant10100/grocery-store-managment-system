<?php
    include("adminnavbar.php");
    include("database.php");
    echo $id = $_GET["id"];

    $sql = "delete from addproduct where id = $id";
    $result = mysqli_query($conn,$sql);
    if($result)
    {
        header("location:manageproduct.php");
    }
?>