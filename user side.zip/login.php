<?php
session_start();
include('database.php');
error_reporting(0);

// Database Connection
$conn = mysqli_connect("localhost", "root", "", "onlinegrocery");

if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

if (isset($_POST["submit"])) {
    $username = trim($_POST["username"]);
    $password = trim($_POST["password"]);

    if (empty($username) || empty($password)) {
        echo "<script>alert('Please enter both username and password!'); window.location.href='login.php';</script>";
        exit();
    }

    $_SESSION['username'] = $username;

    // Admin Login
    if ($username === "prashant" && $password === "12345678") {
        header("Location: admin/admindashbord.php");
        exit();
    }

    // User Login (Using Prepared Statements)
    $query = "SELECT * FROM newregistration WHERE username = ? AND password = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $_SESSION['username'] = $username;
        header("Location: fhome.php");
        exit();
    } else {
        echo "<script>alert('Invalid username or password'); window.location.href='login.php';</script>";
    }

    // Close Connection
    $stmt->close();
    $conn->close();
}
?>

<html>
<head>
    <title>signup</title>
    <style>
        *{
			margin:0px;
			padding:0px;
			box-sizing: border-box;
			font-family: "Poppins", sans-serif;
		}
		
		:root {
				--primary-color:rgb(110, 103, 103);
				--second-color:rgb(102, 95, 95);
				--black-color: #000000;
			  }
			 
		
		body{
				   background-image:url("loginimg.jpg"); 
				   background-position: center;
				   background-size: cover;
				   background-repeat: no-repeat;
				   background-attachment: fixed;
				   
		}
		
		a{
			text-decoration: none;
		}
		
		
		
				
		input-field{
						width: 100%;
						height: 55px;
						font-size: 16px;
						background: White;
						border-radius: 30px;
						outline: none;
		}
		.register {
						text-align: center;
						display: relative;
				  }
				  
		.forgot{
						text-align: center;
						margin-top: -28px;
						margin-right: 20px;
			   }
			   
		
				.wrapper {
						margin: 150px;
						margin-left: 550px;
						position: fixed;
						width: 400px;
						height: 500px;
						background: transparent;
						box-shadow: 0 0 50px;
						border-radius: 20px;
  						padding: 40px;
  						overflow: hidden;
						justify-content: space-between;
						padding-top: 10%;
						backdrop-filter: blur(5px);
						}
				
		.login_box {
						  position: relative;
						 
				   }
				
		.login-header span {
								font-size: 30px;
								
						   }
						   
		.input-field {
								width: 100%;
								height: 60px;
								font-size: 16px;
								background: transparent;
								padding-inline: 20px 60px;
								border: 2px solid var(--primary-color);
								border-radius: 30px;
								outline: none;
					 }
	
  
		

		
		.login-header{
						position: absolute;
						top: 0;
					    left: 50%;
						transform: translateX(-50%);
						display: flex;
						align-items: center;
						justify-content: center;
						width: 140px;
						height: 70px;
						border-radius: 0 0 20px 20px;
					
					}
					
		.input_box{
					margin-top: -70px;
					font-size: .8em;
					color: #fff;
					padding: 10 10px;
					font-size: 16px;
}
				 
				 
		.input-submit {
						width: 100%;
						height: 50px;
						background:rgb(124, 102, 102);
						font-size: 20px;
						font-weight: 500;
						border: none;
						border-radius: 30px;
						cursor: pointer;
						transition: 0.3s;
					  }
					
		.remember-forgot {
							  display: flex;
							  justify-content: space-between;
							  font-size: 15px;
							  height:15px;
							 
						 }
						 
		.input-box{
						margin-top: -40px;
						font-size: .8em;
						color: #fff;
						padding: 50 10px;
						font-size: 16px;
		}
    
	
	.remember-me{
					margin-top: -30px;
					margin-left: 10px;
	}
	
	.account{
					margin-left: 40px;
					
	}	
	
	.regi{
			margin-left: 10px;
	}
	</style>
</head>
<body>
	<form method="POST">
    <div class="wrapper">
		<div class="login-box">
		<div class="login-header">
		<h1 style="color:white"><span>Login</span><br></h1>
		</div>
		
		<div class="input_box">
			<label style="color:white" for="user" class="label"  placeholder="Enter Username">Username </label><br><br>
			<span style="color: red;"></span>
			<input type="text"name="username" class="input-field">
		</div>
		
		<div class="input-box">
			<label style="color:white"for="pass" class="label" name="password" placeholder="Enter Password">Password </label><br><br>
			<input type="password" name="password" class="input-field">
		</div>
		
		<div class="remember-forgot">
			<div class="remember-me">
			<input  type="checkbox">
			<label style="color:white" class="remember" >Remember Me? </label>
		</div>

		<div class="forgot">
				<a href="forgetpassword.php" style="color:skyblue">Forgot password?</a>
		</div>
		</div>
		
		<div>
			<button name="submit" type="submit" class="input-submit">Submit<br>
		</div>
		
		<div><br>
			<span style="color:skyblue" class="account">Don't have an account? <a href="newregistration.php" class="regi" style="color: skyblue">Register <a href="Registration.php"></a></span>
		</div>
	</div>
</div>
	</form>
</body>
</html>