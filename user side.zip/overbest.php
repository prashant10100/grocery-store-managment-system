

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="overbest.css">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>

    <div class = containero>
      <div class = cardo>
        <div class = imageo>
          <img href = "#" src = "images/b-2.jpeg">
        </div>
        <div class = contento>
          <h3>The Ice-cold Drink</h3>
          <p>In Summer The Ice-Cold Drink is our Top Selling Product,           The Demand Of It Is Verry High                It Is our 1'st top sell Item.</p>
        </div>
      </div>    
      <div class = cardo>
        <div class = imageo>
          <img href = "#" src = "images/b-4.jpeg">
        </div>
        <div class = contento>
          <h3>The Rosted Makhana </h3>
          <p>The Rosted Makhana Is All time Sell Item ,           During Winter The Demand Of It Is Verry High               It Is our 2'st top sell Item.</p>
        </div>
      </div>   
      <div class = cardo>
        <div class = imageo>
          <img href = "#" src = "images/c13.jpg">
        </div>
        <div class = contento>
          <h3>Dairy-Milk Fruit And Nuts</h3>
          <p>Dairy-Milk Fruit And Nuts Is Most Sell On Special Days,         During Valantine Week The Demand Of It Is Verry High          It Is our 3'st top sell Item.</p>
        </div>
      </div>   
      
    </div>
  </body>

</html>