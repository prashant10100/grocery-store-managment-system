<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Spices of the World</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
        }

        header {
            text-align: center;
            padding: 2rem;
            background-color: #f4f4f4;
        }

        header img {
            max-width: 100%;
            height: auto;
            margin: 1rem 0;
        }

        section {
            padding: 2rem;
            margin: 0 auto;
            max-width: 1200px;
        }

        .section-title {
            text-align: center;
            margin-bottom: 2rem;
            font-size: 1.8rem;
            color: #8B4513;
        }

        .features {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 1rem;
        }

        .feature {
            flex: 1 1 calc(25% - 1rem);
            background-color: #ffe4b5;
            padding: 1rem;
            border-radius: 5px;
            text-align: center;
        }

        .feature img {
            max-width: 50px;
            margin-bottom: 1rem;
        }

        .image-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 2rem;
        }

        .image-content img {
            max-width: 48%;
            height: auto;
            border-radius: 5px;
        }

        .content {
            max-width: 50%;
        }
    </style>
</head>
<body>
    <header>
        <h1>The Richest Spices in the World</h1>
        <img src="pic-1.jpg" alt="Assorted spices">
        <p>Discover the vibrant world of spices that bring life to your culinary creations.</p>
    </header>

    <section>
        <h2 class="section-title">Unique Flavors of Spices</h2>
        <div class="features">
            <div class="feature">
                <img src="icon1.png" alt="Flavor Icon">
                <h3>Flavor</h3>
                <p>Rich and aromatic blends that elevate every dish.</p>
            </div>
            <div class="feature">
                <img src="icon2.png" alt="Export Icon">
                <h3>Export</h3>
                <p>Premium spices exported worldwide for global taste.</p>
            </div>
            <div class="feature">
                <img src="icon3.png" alt="Quality Icon">
                <h3>Quality</h3>
                <p>Uncompromised quality straight from the finest farms.</p>
            </div>
            <div class="feature">
                <img src="icon4.png" alt="Tasting Icon">
                <h3>Tasting</h3>
                <p>Delight your palate with our exquisite spice selections.</p>
            </div>
        </div>
    </section>

    <section>
        <h2 class="section-title">A Unique Blended Taste</h2>
        <div class="image-content">
            <div class="content">
                <h3>The Magic of Spice</h3>
                <p>Delight in the harmony of vibrant flavors and the art of blending to perfection.</p>
            </div>
            <img src="pic-2.jpg" alt="Assorted spices in bowls">
        </div>

        <div class="image-content">
            <img src="pic-3.jpg" alt="Spices in sacks">
            <div class="content">
                <h3>The Grand Market</h3>
                <p>Explore the colorful spice markets with aromas that captivate the senses.</p>
            </div>
        </div>
    </section>
</body>
</html>
