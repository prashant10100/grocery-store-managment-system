

<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
		 body{
				width: 100%;
				height: 5vh;
				text-align: center;
				font-weight: bold;
				background-position: center;
				background-size: cover;		
				margin-bottom: 50%;
				background-repeat:no-repeat;
				background-position: center;
		 }
		 
nav{
				background-position: center;			   
				background-repeat: no-repeat;
				width: 200%;
				height: 150px;
				background-color: #153242;
				align-items: left;
				display: flex;
				align-items: center;
				justify-content: space-between;	
				padding-left: 190px;
				position: absolute;
			    left: -1490px;
				margin-left: 50px;
				background-size: 120px;
				background-image:url("4.png");
				position: fixed;
				top: 0px; 
	}

	 .menu{
               width:65%;
               display: flex;
               justify-content:right;
               list-style: none;
               width: 100%;
               justify-content: center;
               align-items: center;
               min-height: 100vh;
               font-size: 1.1em;
               color: #fff;
               text-decoration: none;
               font-weight: 500;
               margin-left: 1400px;
   }

                           
   .menu a::after{
                       content: " ";
                       position: absolute;
                       width: 100%;
                       height: 3px;
                       background: #fff;
                       left: 0;
                       bottom: -6px;
                       border-radius: 5px;
                       transform: scaleX(0);
                       transition: transform .5s;
                       transform-origin: right; 
   }

   .menu a:hover::after{
                           transform: scaleX(1);
                           transform-origin: left; 
   }
   
  
   .menu li{
               margin-left: 15px;     /*for space between text*/
   }
   
  
   .menu a{
               position: relative;
               font-size: 1.1em;
               color: #fff;
               text-decoration: none;
               font-weight: 500;
   }
	
	.search{
				display: flex;
				align-items: center;
				margin-left: 140px;
	}
	
	.search form {
						display: flex;
						margin: -120px;
						margin-right: 200px;
						
	}
	
	.search input{
					padding: 8px;
					border: 1px solid #ddd;
					outline: none;
					border-radius: 20px;
					margin-right: 20px;
					font-size: 16px;
					
	}	
	
	.search input:hover{
							border: 1px solid;
	}
	
	
	
	
		
			*{
				margin: 0;
				padding: 0;
				box-sizing: border-box;
		 }
		 
	.container{
					width: 100%;
					height: auto;
					position: relative;
					padding-top: 120px;
					
			   }
			  
			.container img{
								width: 100%;
								height: 732px;								
						  }
						  
		     .container .text{
								 position: absolute;
								 color: white;
								 left: 50%;
								 top: 60%;
								 transform: translate(-50%,-50%);
								 font-size: 60px;
								 padding-bottom: 100px;
			 }

.f1{
		background-image: url("p3.jpg");
		min-height: 45vh;
		font-size: 6vh;
		justify-content: center;
		text-align: center;
		flex-direction: column;
		justify-content: space-around;
		background-attachment: fixed;
		color: white;
		height: 60px;
		padding: 100px;
		margin-bottom: 9%;
		display: block;
		width: 100%;
		background-size: cover;
		background-position: 10%;
}	

.f1 h2{
			margin-top: -10px;
}
 
  .p4 h2{
		height: 550px;
		width: 100%;
  }
  
 
  .hh{
		background-color: white;
  }
  
.p2 {
	margin-top: -80px;
			height: 500px;
			justify-content: space-evenly;
			display: flex;
			margin-bottom: 60px;
}

.p2 .s1{
			height: 100%;
			
			
}

.p2 .s2{
			height: 100%;
		}
		
.p2 .s3{
		
			height: 100%;
		
			
	   }   
			
		nav li{
					padding: 15px;
		}
		
			
		.p1 .k1{
					height: 500px;
					width: 480px;
					margin-left: -850px;

			}		
		
		.p1{
				height: 100px;
				margin-top: 50px;
				padding-top: 500px;
		}
		
		.h11{
				margin-top: -150px;
				color: dark black;
				font-size: 35px;
				font-family: Wide Latin;
		}
		
		.imageinconteiner{
							width: 25vw;
							height: 50vh;
							margin-top: -250px;
							border-radius: 20px;
						 }
					
						
		.oursconteiner{
							margin-top: -280px;
							padding: 50px;
		}

  .p3 {
	  	    background-image:url("s4.jpeg");
			color: #f0f3f5;
			height: 150%;
			width: 100%;
			padding: 300px;
			background-repeat: no-repeat;
			background-size: cover;
  }
	
	.h12{
			color: yellow;
	}
	
	button{
				border: none;
				cursor: pointer;
	}
	
	.p3 .yy{
					height: 50px;
					width: 170px;
					border-radius: 500px;
					font-size: 25px;
					
					border-color: #adefd1;
					
				    text-align: center;
				    line-height: 10px;
  }
  
  .p3 button{
				height: 50px;
				width: 170px;
				border-radius: 500px;
				font-size: 25px;
  }
  
		.yy::before{
						content: "";
						height: 3em;
						width: 0;
						border-radius: 30em;
						position: absolute;
						top: -10;
						left: 0;
						transition: .5s ease;
						display: block;
						z-index: -1;
		}

	.yy:hover::before{
						width: 9em;
	}		
	
	.yy{
			z-index: 1;
			box-shadow: 6px 6px 12px #c5c5c5,-6px -6px 12px #ffffff; 
			width: 15em;
			z-index: 1;
			cursor:pointer;
			left: 10px;
	}
 
 .icon{
		width: 50px;
		color: white;
		margin: 10px;
		padding-right: 10px;
		font-size: 25px;
	  }
	
.icon2{
			color: white;
			margin: 10px;
			padding-right: 25px;
			font-size: 25px;
}
	
.icon3{
			color: white;
			font-size: 25px;
			padding-right: 35px;
			margin: 10px;

}
	
.icon4{
			color: white;
			font-size: 25px;
			margin: 10px;
			margin-right: -40px;
			
}

.container1{
	max-width: 1570px;
	margin:auto;
}
.row{
	display: flex;
	flex-wrap: wrap;
}
ul{
	list-style: none;
}

.footer{
	background-color: #24262b;
    padding: 100px 100;
}
.footer-col{
   width: 25%;
   padding: 20 55px;
}
.footer-col h4{
	font-size: 18px;
	color: #ffffff;
	text-transform: capitalize;
	margin-bottom: 35px;
	font-weight: 500;
	position: relative;
}
.footer-col h4::before{
	content: '';
	position: absolute;
	left: 80px;
	bottom: -10px;
	background-color: #e91e63;
	height: 2px;
	box-sizing: border-box;
	width: 60px;
}
.footer-col ul li:not(:last-child){
	margin-bottom: 10px;
}
.footer-col ul li a{
	font-size: 16px;
	text-transform: capitalize;
	color: #ffffff;
	text-decoration: none;
	font-weight: 300;
	color: #bbbbbb;
	display: center;
	transition: all 0.3s ease;
}
.footer-col ul li a:hover{
	color: #ffffff;
	padding-left: 8px;
}
.footer-col .social-links a{
	display: inline-block;
	height: 40px;
	width: 40px;
	background-color: rgba(255,255,255,0.2);
	margin:0 10px 10px 0;
	padding-top: 10px;
	text-align: center;
	line-height: 40px;
	border-radius: 50%;
	color: #ffffff;
	transition: all 0.5s ease;
}
.footer-col .social-links a:hover{
	color: #24262b;
	background-color: #ffffff;
}




    </style>
</head>
<body>
<section>
	<div class="container">
		<img src="s3.jpeg">
		<div class="text"><h2>Grocery Heven</h2><br>
		 <h6> A Complete Place For Shopping </h6> 
	</div>
</section>  
<nav>
			 <ul class="menu"> 
				 <li><a href="#">Home </a></li>
				 <li><a href="shop.php">Shops</a></li>
				 <li><a href="#">Services </a></li>
				 <li><a href="login.php">Login</a></li>
				 <li><a href="extra2.php">Custometr Review</a></li>
				 <li><a href="contact.php">Contact Us</a></li>
			 </ul> 
	</div>
			</div>
			
	<div class="search">
		<form method="post">
			<input type="text" placeholder="Search...">
			
			<div class="icon">
				<i class="fa-solid fa-magnifying-glass"></i>
			</div>

			<div class="icon2">
				<i class="fa-regular fa-heart"></i>
			</div>
			
			<div class="icon3">
				<i class="fa-solid fa-cart-shopping"></i>
			</div>
			
			<div class="icon4">
				<i class="fa-solid fa-user"></i>
			</div>
		</form>
		</div>
		</nav>
  <div class="oursback">
	<h1>Our Best Product</h1>
	<div class="p1">
	  <table>
            <tr>
                <td>
                    <div class="oursconteiner">
                        <img src="b-2.jpeg" class="imageinconteiner"></image>
                        <br><label class="ourscakename">ice colddrink can</label><br>
                          $ 3 
                    </div>
				</td>
				
				<td>
                    <div class="oursconteiner">
                        <img src="b-3.jpeg" class="imageinconteiner"></image>
                        <br><label class="ourscakename">Lays Waffer</label><br>
                          $ 0.5
                    </div>
				</td>
				
				<td>
                    <div class="oursconteiner">
                        <img src="b-4.jpeg" class="imageinconteiner"></image>
                        <br><label class="ourscakename">Dry-Fruit Makhan</label><br>
                          $ 10
                    </div>
				</td>
			
			</tr>
	</table>
        <br>
		</div>
    </div>
			

	<div class="f1">
		
			<h2>Grocery Heven is not just about products. It's </h2>
			<h2>also about the experience.  </h2>
			
	</div>
	<div class="p2">
		<div>	
			<img src="img-9.jpg" class="s3">
		</div>
		<div>	
			<img src="img-13.jpg" class="s1">
		</div>
		<div>
			<img src="img-14.jpg" class="s2">
		</div>
	</div>
		<div class="p3"> 
				
				<h1 class="h11">Want to know more about our menu? </h1>
				<br><br>
				<h1 class="h12">50% OFF</h1>
				<br>
				<h1 class="h12">All Products </h1>
				<br><br>
				<button class="yy">Our Menu</button>
				<button class="yy">Order Now </button>
		</div>
    </style>	
	
	<?php include "team.php"?>
  <footer class="footer">
  	 <div class="container1">
  	 	<div class="row">
  	 		<div class="footer-col">
  	 			<h4>company</h4>
  	 			<ul>
  	 				<li><a href="#">about us</a></li>
  	 				<li><a href="#">our services</a></li>
  	 				<li><a href="#">privacy policy</a></li>
  	 				<li><a href="#">affiliate program</a></li>
  	 			</ul>
  	 		</div>
  	 		<div class="footer-col">
  	 			<h4>get help</h4>
  	 			<ul>
  	 				<li><a href="#">FAQ</a></li>
  	 				<li><a href="#">shipping</a></li>
  	 				<li><a href="#">returns</a></li>
  	 				<li><a href="#">order status</a></li>
  	 				<li><a href="#">payment options</a></li>
  	 			</ul>
  	 		</div>
  	 		<div class="footer-col">
  	 			<h4>online shop</h4>
  	 			<ul>
  	 				<li><a href="#">watch</a></li>
  	 				<li><a href="#">bag</a></li>
  	 				<li><a href="#">shoes</a></li>
  	 				<li><a href="#">dress</a></li>
  	 			</ul>
  	 		</div>
  	 		<div class="footer-col">
  	 			<h4>follow us</h4>
  	 			<div class="social-links">
  	 				<a href="#"><i class="fab fa-facebook-f"></i></a>
  	 				<a href="#"><i class="fab fa-twitter"></i></a>
  	 				<a href="#"><i class="fab fa-instagram"></i></a>
  	 				<a href="#"><i class="fab fa-linkedin-in"></i></a>
  	 			</div>
  	 		</div>
  	 	</div>
  	 </div>
  </footer>
</head>
	  </div>
	</div>
    </div>
</body>
</html>
