<?php

	$conn=mysqli_connect("localhost","root","","registration");
	
	if(!$conn)
	{
		echo "not connect";
	}
	
	
	if(isset($_POST["s1"]))
	{
		
		 $Name=$_POST["t1"];
		 $age=$_POST["t2"];
		 $email=$_POST["t3"];
		 //$gender=$_POST["t4"];
		 $username=$_POST["t5"];
		 $password=$_POST["t6"];
		 $conformpassword=$_POST["t7"];
		
		$re="INSERT INTO `regi-table`(`Name`, `age`, `email`, `username`, `password`, `conform password`) VALUES ('$Name',$age,'$email','$username',$password,$conformpassword)";
		
		$result=mysqli_query($conn,$re);
		
		 if(!$result)
		 {
			    echo "not insert";
		 }
		 // else
		 // {
				// include 'new project.php';
		 // }
	 }
	 
	
?>

<html>
<head>
    <style>
        *{
                margin: 0;
                padding: 0;
				padding: 5px;
				background-repeat: no-repeat;
        }
        
          body{
                 
                    background-image:url("demo.jpg");
                    background-repeat: no-repeat;
                   background-position:center;
                    background-size:100%;
					font-size: 20px;
                    /*this for login text to set center*/
                    height: 100vh;
					width: 100%;
                    display: flex;
                    align-items: center;
                    justify-content: center;
					color: red;
					background-color: black;
                }
                
                .main {
						margin: 150px;
						margin-left: 200px;
						position: relative;
						width: 400px;
						height: 700px;
						background: transparent;
						box-shadow: 0 0 50px;  //aana thi box thay new project ma shop page ma mukvanu
						border-radius: 20px;
  						padding: 40px;
  						overflow: hidden;
						justify-content: center;
						padding-top: 20%;
						backdrop-filter: blur(5px);
                        display: flex;
                        align-items: center;
						padding-bottom: 40px;
						}

            .p1{
                border-radius: 70px;
                height: 28px;
                width: 100%;
            }

            .p2{
                border-radius: 70px;
                height: 28px;
                width: 100%;
            }


            .p3{
                border-radius: 70px;
                height: 28px;
                width: 100%;
            }


            .p4{
                border-radius: 70px;
                height: 28px;
                width: 100%;
            }


            .p5{
                border-radius: 70px;
                height: 28px;
                width: 100%;
            }


            .p6{
                border-radius: 70px;
                height: 28px;
                width: 100%;
            }


            .btn{
                    height: 45px;
                    width: 100%;
                    border-radius: 50px;
            }

            .main .btn-login:hover{
                                          background: #fff;
                                          color: #162938;
                                  }

        .main .btn-login{
                    width: 100px;
                    height: 50px;
                    background: transparent;
                    border: 2px solid #fff;
                    outline: none;
                    border-radius: 10px;
                    cursor: pointer;
                    font-size: 1.1em;
                    color: #fff;
                    font-weight: 500;
                    margin-left: 0px;
                    transition: 5%;
                    width: 100%;
                    height: 40px;
                }
                h2{
                    margin-top: -18vh;
                    margin-bottom: 10px;
                    margin-left: 15px;
                    
                }
				
				section{
							display: flex;
							justify-content: center;
							align-items: center;
							width: 100%;
							height: 100px;
				}
				
				.btn-login{
								include 'new project.php';
				}
			
        </style>
    </head>
    <body>
	<section>
	<form method="POST">
        <div class="main">
            <div class="register">
            <h2 style="color:white">Registration</h2>
            <br>
            <label style="color:white"> Name :</label>
            <br>
            <input type="text" name="t1" id="name" class="p1" placeholder="Enter Your First Name"><br><br>
            
            
            
            <label style="color:white">Your Age :</label>
            <br>
            <input type="number" name="t2" id="name" class="p2" placeholder="How Old Are You"><br><br>
            
            <label style="color:white">Email :</label>
            <br>
            <input type="text" name="t3" id="name" class="p3" placeholder="Enter Your E-mail"><br><br>
            
			
            <label  style="color:white">Gender :</label>
            <br>
            <input type="radio" name="gender" id="male">
            <span  style="color:white" id="male">male</span>
            
            <input type="radio" name="gender" id="female">
            <span  style="color:white" id="female">female</span><br><br>
            
            <label style="color: white" class="p4">User Name :</label>
            <br>
            <input type="text" name="t5" id="name" class="p4" placeholder="Enter Your User Name"><br><br>
            
            <label  style="color:white">Password :</label>
            <br>
            <input type="password" name="t6" class="p5" id="name" placeholder="Enter 8 digit password"><br><br>
            
            
            <label  style="color:white" class="p6">Conform Name :</label>
            <br>
            <input type="password" name="t7" id="name" class="p6" placeholder="Enter 8 digit password"><br><br>
            <br>
            <input type="submit" value="submit" name="s1" class="btn-login">
             
            </div><!--end register-->
        </div><!--end main-->
		</section>
		</form>
    </body>
    </html>



