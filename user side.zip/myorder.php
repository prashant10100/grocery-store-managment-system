<?php
session_start();
include("database.php");
$user=$_SESSION['username'];
$sqlorder = mysqli_query($conn, "select * from orders where username = '$user'");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Placed Orders</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        .order-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
        }
        .order-card {
            background: white;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 350px;
            border: 1px solid lightgray;
            text-align: left;
        }
        .order-card h2 {
            color: black;
            font-size: 20px;
            text-align: center;
        }
        .order-card p {
            color: green;
            margin: 5px 0;
        }
        .order-card strong {
            color: black;
            display: inline-block;
            width: 140px;
            vertical-align: top;
        }
        .order-card .pending {
            color: red;
            font-weight: bold;
        }
        .order-card img {
            width: 120px;
            height: 120px;
            object-fit: contain;
            display: block;
            margin: 10px auto;
            border-radius: 5px;
        }
        .order-card .address {
            display: inline;
        }
    </style>
</head>
<body>
    <h1 style="text-align:center;">PLACED ORDERS</h1>
    <div class="order-container">
        <?php
            while($rorder = mysqli_fetch_assoc($sqlorder))
            {
        ?>
        <div class="order-card">
            <img src="admin/images/addproduct/<?php echo $rorder['image']; ?>" alt="Product Image">
            <!-- <p><strong>Placed on:</strong> <?php echo $rorder['date']; ?></p> -->
            <p><strong>Name:</strong> <?php echo $rorder['name']; ?></p>
            <p><strong>Number:</strong> <?php echo $rorder['number']; ?></p>
            <p><strong>Email:</strong> <?php echo $rorder['email']; ?></p>
            <p><strong>Address:</strong> <span class="address"><?php echo $rorder['fullAddress']; ?></span></p>
            <p><strong>Payment Method:</strong> <?php echo $rorder['method']; ?></p>
            <p><strong>Your Orders:</strong> <?php echo $rorder['p_name']; ?> (<?php echo $rorder['qty']; ?>)</p>
            <p><strong>Total Price:</strong> Rs. <?php echo $rorder['g_total']; ?>/-</p>
            <p><strong>Order Status:</strong> <?php echo $rorder['order_status']; ?></p>
        </div>
        <?php
            }
        ?>
    </div>
</body>
</html>