<?php
session_start();
include("database.php");

$sqlcart = mysqli_query($conn, "SELECT * FROM cart WHERE uid = '$_SESSION[username]'");
// $ord = mysqli_query($conn, "SELECT * FROM addproduct    WHERE uid = '$_SESSION[username]'");
$sqlreg = mysqli_query($conn, "SELECT * FROM newregistration WHERE username = '$_SESSION[username]'");
$resreg = mysqli_fetch_assoc($sqlreg);

if (isset($_POST['placeorder'])) {
    // Collect user input
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $number = mysqli_real_escape_string($conn, $_POST['number']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $method = mysqli_real_escape_string($conn, $_POST['payment']);
    $address1 = mysqli_real_escape_string($conn, $_POST['address1']);
    $address2 = mysqli_real_escape_string($conn, $_POST['address2']);
    $city = mysqli_real_escape_string($conn, $_POST['city']);
    $state = mysqli_real_escape_string($conn, $_POST['state']);
    $country = mysqli_real_escape_string($conn, $_POST['country']);
    $pincode = mysqli_real_escape_string($conn, $_POST['pincode']);

    // Combine full address
    $full_address = "$address1, $address2, $city, $state, $country - $pincode";

    $grand_total = 0;
    while ($recart = mysqli_fetch_assoc($sqlcart)) {
        $grand_total += ($recart['quantity'] * $recart['price']);

        // Proper SQL query
        $sql = "INSERT INTO `orders`(`name`,`username`,`image`, `number`, `email`, `method`, `fullAddress`,`p_name`, `qty`, `p_price`, `g_total`,`order_status`) 
                VALUES ('$name','$_SESSION[username]','$recart[image]', '$number', '$email', '$method', '$full_address','$recart[name]','$recart[quantity]', '{$recart['price']}', '$grand_total','pending')";

        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Order placed successfully!');</script>";
            // echo $hr=("update addproduct set  qty=qty-$recart[quantity] WHERE iname=$recart[name]");
             $update=mysqli_query($conn,"update addproduct set  qty= qty- $recart[quantity] WHERE image='$recart[image]'" );
             ?>
             <script>
                alert("Updated");
             </script>
             <?php

            $cartdelete = mysqli_query($conn, "delete from cart where uid = '$_SESSION[username]'");

        } else {
            echo "<script>alert('Order not inserted: " . mysqli_error($conn) . "');</script>";
        }
       "$recart[name]";
    }
}

// Remove this line to keep connection open
// $conn->close();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Place Your Order</title>
    <link rel="stylesheet" href="orderstyle.css">
    <style>
        .item-container {
            display: flex;
            justify-content: center;
            gap: 10px;
        }

        .item {
            border: 2px solid black;
            padding: 10px 15px;
            border-radius: 8px;
            font-size: 18px;
            display: inline-block;
        }

        .price {
            color: red;
            font-weight: bold;
        }

        .total {
            margin-top: 20px;
            font-size: 22px;
            font-weight: bold;
            color: gray;
        }

        .total span {
            color: red;
        }
    </style>
    <script>
        function validateForm() {
            let name = document.forms["orderForm"]["name"].value;
            let number = document.forms["orderForm"]["number"].value;
            let email = document.forms["orderForm"]["email"].value;
            let payment = document.forms["orderForm"]["payment"].value;
            let address1 = document.forms["orderForm"]["address1"].value;
            let city = document.forms["orderForm"]["city"].value;
            let state = document.forms["orderForm"]["state"].value;
            let country = document.forms["orderForm"]["country"].value;
            let pincode = document.forms["orderForm"]["pincode"].value;

            let namePattern = /^[A-Za-z\s]+$/;
            let numberPattern = /^[0-9]{10}$/;
            let emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            let cityStateCountryPattern = /^[A-Za-z\s]+$/;
            let pinPattern = /^[0-9]{6}$/;

            if (!name.match(namePattern)) {
                alert("Please enter a valid name (only letters and spaces).");
                return false;
            }
            if (!number.match(numberPattern)) {
                alert("Please enter a valid 10-digit phone number.");
                return false;
            }
            if (!email.match(emailPattern)) {
                alert("Please enter a valid email address.");
                return false;
            }
            if (payment == "") {
                alert("Please select a payment method.");
                return false;
            }
            if (address1.trim() == "") {
                alert("Address Line 1 cannot be empty.");
                return false;
            }
            if (!city.match(cityStateCountryPattern)) {
                alert("City should contain only letters.");
                return false;
            }
            if (!state.match(cityStateCountryPattern)) {
                alert("State should contain only letters.");
                return false;
            }
            if (!country.match(cityStateCountryPattern)) {
                alert("Country should contain only letters.");
                return false;
            }
            if (!pincode.match(pinPattern)) {
                alert("Please enter a valid 6-digit pin code.");
                return false;
            }

            return confirm("Are you sure you want to insert?");
        }
    </script>
</head>

<body>


    <div class="container">
        <?php
        $grand_total = 0;
        while ($recart = mysqli_fetch_assoc($sqlcart)) {

            $grand_total = $grand_total + ($recart['quantity'] * $recart['price']);
            // $sql = "INSERT INTO `orders`(`id`, `name`, `number`, `email`, `method`, `fullAddress`, `qty`, `p_price`, `g_total`) 
            // VALUES ('id','$resreg[name]','$resreg[mno]',' $resreg[email]','CODss','pd','$recart[quantity]','$recart[price]','$grand_total')";

            // if ($conn instanceof mysqli && $conn->ping()) {
            //     $re = mysqli_query($conn, $sql);
            // } else {
            //     echo "Database connection is closed!";
            // }

        ?>
            <!-- <h3><?php //$recart['name'];
                        ?></h3>
            <label></label>
            <label><?php //$recart['price']; 
                    ?></label>
            <label><?php // $grand_total; 
                    ?></label> -->

            <!-- <div class="item-container">
                
                <label class="quantity">Price : </label> -->

                <div class="item-container">
                <label class="item">Product Name : <?php echo $recart['name']; ?></label>
                <label class="item">Quantity : <?php echo $recart['quantity']; ?></label>
                <div class="item"> price: <?php echo $recart['price']; ?></div>
                </div>

              

            <!-- </div> -->


        <?php
        }

        ?>
        <center><label class="total">Grand Total : <span><?php echo $grand_total; ?></span></label></center>
        <h2>PLACE YOUR ORDER</h2>
        <form name="orderForm" method="post">
            <div class="row">
                <div class="column">
                    <label>Your Name:</label>
                    <input type="text" name="name" placeholder="Enter your name" required>
                </div>
                <div class="column">
                    <label>Your Number:</label>
                    <input type="text" name="number" placeholder="Enter your number" required>
                </div>
            </div>

            <div class="row">
                <div class="column">
                    <label>Your Email:</label>
                    <input type="email" name="email" placeholder="Enter your email" required>
                </div>
                <div class="column">
                    <label>Payment Method:</label>
                    <select name="payment" required>
                        <option value="">Select Payment Method</option>
                        <option value="cash">Cash on Delivery</option>
                        <option value="credit">Credit Card</option>
                        <option value="paytm">Paytm</option>
                        <option value="paypal">Paypal</option>
                    </select>
                </div>
            </div>

            <div class="row">
                <div class="column">
                    <label>Address Line 01:</label>
                    <input type="text" name="address1" placeholder="e.g. flat number" required>
                </div>
                <div class="column">
                    <label>Address Line 02:</label>
                    <input type="text" name="address2" placeholder="e.g. street name">
                </div>
            </div>

            <div class="row">
                <div class="column">
                    <label>City:</label>
                    <input type="text" name="city" placeholder="e.g. botad" required>
                </div>
                <div class="column">
                    <label>State:</label>
                    <input type="text" name="state" placeholder="e.g. gujarat" required>
                </div>
            </div>

            <div class="row">
                <div class="column">
                    <label>Country:</label>
                    <input type="text" name="country" placeholder="e.g. India" required>
                </div>
                <div class="column">
                    <label>Pin Code:</label>
                    <input type="text" name="pincode" placeholder="e.g. 364710" required>
                </div>
            </div>

            <button type="submit" name="placeorder" class="place-order">Place Order</button>
        </form>
    </div>

</body>

</html>