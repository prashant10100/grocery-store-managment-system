<?php
error_reporting(0);
session_start();
include("database.php");
    $sqlwish = mysqli_query($conn,"select * from wishlist where uid = '$_SESSION[username]'");
    $sqlr = mysqli_fetch_assoc($sqlwish);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wishlist</title>
    <style>
      body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f8f8f8;
}

.wishlist-container {
    max-width: 900px;
    margin: 20px auto;
    background: white;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
}

h2 {
    background: #3357c5;
    color: white;
    text-align: center;
    padding: 15px;
    margin: 0;
    font-size: 24px;
}

.recently-added {
    font-size: 18px;
    font-weight: bold;
    margin-bottom: 15px;
}

.wishlist-item {
    display: flex;
    align-items: center;
    border-bottom: 1px solid #ddd;
    padding: 15px 0;
}

.wishlist-item img {
    width: 50px;
    height: 50px;
    margin-right: 15px;
}

.wishlist-item-info {
    flex-grow: 1;
}

.wishlist-item-info p {
    margin: 5px 0;
    font-size: 14px;
}

.wishlist-item-info p:first-child {
    font-weight: bold;
}

.wishlist-item-buttons {
    display: flex;
    gap: 10px;
}

.wishlist-item-buttons a,
.wishlist-item-buttons button {
    padding: 8px 12px;
    border: none;
    cursor: pointer;
    border-radius: 3px;
    color: white;
}

.remove {
    background-color: red;
    text-decoration: none;
}

.move-to-cart {
    background-color: blue;
    text-decoration: none;
}

.continue-shopping {
    margin-top: 15px;
    display: inline-block;
    padding: 8px 12px;
    background-color: #ddd;
    text-decoration: none;
    color: black;
    border-radius: 3px;
}

    </style>
</head>
<body>
<h2>Your Wishlist</h2>
    <div class="wishlist-container">
        <?php
        $sql = "SELECT * FROM wishlist WHERE uid = '$_SESSION[username]'";
        $result = mysqli_query($conn,$sql);
        
        if ($result->num_rows > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
              
                echo "<div class='wishlist-item'>";
                echo "<img src='Admin/images/addproduct/{$row['image']}' alt='Item Image'>";
                echo "<div class='wishlist-item-info'>";
                echo "<p>{$row['name']}</p>";
                echo "<p>Price: Rs. {$row['price']}</p>";
                echo "</div>";
                echo "<div class='wishlist-item-buttons'>";
                echo "<a href='removewish2.php?id=$row[id]' class='remove'>Remove</a>";
                // echo "<button class='move-to-cart'>Add to Cart</button>";
                ?>
                 <a href="cartdesc.php?id=<?php echo $row['name']; ?>" class="move-to-cart">Add to Cart</a>

        
                <?php
                echo "</div>";
                echo "</div>";
            }
        } else {
            echo "<p>No products in your wishlist.</p>";
        }
        
        // Close the connection
        $conn->close();
        ?>
    </div>
</body>
</html>
