<html><head>
<meta http-equiv="content-type" content="text/html; charset=windows-1252">
    <style>
		 body{
				width: 100%
				height: 5vh;
				//background-image:url("1.jpg");
				text-align: center;
				font-weight: bold;
				background-position: center;
				background-size: cover;		
				margin-bottom: 50%;
				background-repeat:no-repeat;
				background-position: center;
		 }
		 
		 nav{
				//margin-bottom: 10px;
				background-position: center;
				//background-size: cover;				   
				background-repeat:no-repeat;
				width: 100%;
				height: 150px;
				background-color: black;
				align-items: left;
				display: flex;
				align-items: center;
				justify-content: space-between;
				padding: 0px 20px;			
				position: fixed;
                background-image:url("logo.jpg");
				left: 50px;
				margin-left: 10px;
				background-size: 80px;
				top: 0px; // aana thi navigation aakhu niche aave
	}

	 .menu{
                 width:65%;
                 display:flex;
                 justify-content: left;
                 list-style: none;
                 align-items: center;
                 min-height: 5vh;
                position: relative;
                // font-size: 1.1em;
                color: #fff;
                 font-weight: 500;
				 
               
    }
	
	.menu li{
				margin-left: 20px;
	}
	
	.menu li a{
					font-size: 19px;
					color: #fff;
					//margin-left: -25px;
					text-decoration: none;
					margin-right: 20px;
					transition: 0.3s ease;
	}
	
	.menu li a:hover{
							color: #ccc;
	}
	.search{
				display: flex;
				align-items: center;
				margin-right: 300;
				margin-left: 300px;
	}
	
	.search form {
						display: flex;
						margin: -150px;
						
	}
	
	.search input{
					padding: 8px;
					border: 1px solid #ddd;
					outline: none;
					border-radius: 20px;
					margin-right: 10px;
					font-size: 16px;
					
	}	
	
	.search input:hover{
							border: 1px solid #72a0d4;
	}
	
	.search button{
						padding: 10px;
						background-color: #fff;
						border: none;
						border-radius: 5px;
						color: black;
						font-size: 16px;
						cursor: pointer;							
	} 
	
	.search button:hover{
							background-color: #ccc;
	}
	
	
	.logo{
		       margin-left: -100%;
			   font-size: 32px;
			   font-weight: bold;
			   color:red;
	}
	p{
			color: red;
	}
	
			*{
				margin: 0;
				padding: 0;
				box-sizing: border-box;
		 }
		 
	.container{
					width: 100%;
					height: auto;
					//background-position: center;
					position: relative;
					//background-size: cover;		
					//margin-bottom: 50%;
					//background-repeat: no-repeat;
					//background-position: center;
					
			   }
			  
			.container img{
								width: 100%;
						  }
						  
		     .container .text{
								 position: absolute;
								 color: white;
								 left: 50%;
								 top: 50%;
								 transform: translate(-50%,-50%);
								 font-size: 50px;
			 }
			 
			 .learn button{
								font-color: white;
								background-color: #001a32;
								border-radius: 10px;
								border-color: #00182f;
								font-size: 25px;
								width: 200px;
								height: 50px;
								color: #FFFFFF;
								left: 50px;
								font-family: "Poppins", "Odoo Unicode Support Noto", sans-serif;
							
								btn-hover-bg: #001b36;
							
			 }
			 
		.p1{
				height: 100px;
		}		

.f1{
		background-color: black;
		//top: 100%;
		min-height: 55vh;
		font-size: 6vh;
		color: blue;
		justify-content: center;
		text-align: center;
		flex-direction: column;
		justify-content: space-around;
		background-attachment: fixed;
		color: white;
		background-size: 10px;
		height: 110px;
}	

.f1 .h2{
			
}

.p2 .img{
			height: 100px;
			width: 10%;
}

.p3 {
			background-color: #00203f;
			color: #f0f3f5;
			height: 100px;
			position: absolute;
			border: none;
			width: 100%;
  }
  
  .p4{
		height: 100px;
		width: 100%;
		
  }
    </style>
</head>
<body>
	<div class="container">
		<img src="output_files/1.jpg" alt="">
		<div class="text"> <h2>Good Food Services </h2>
		<br> <h6> Explore our selection of delicious meals, made fresh daily. </h6> 
		<div class="learn"><button> Learn More</button> </div></div>
	</div>
	<div class="p1"> 
			<img src="output_files/d1.jpg">
			<img src="output_files/d2.jpg">
			<img src="output_files/d3.jpg">
	
	<div class="f1">
			<h2>Good food is not just about taste. It's </h2>
			<h2>also about the experience.  </h2>
			
	</div>
	<div class="p2">
						<img src="output_files/p1.jpg">
						<img src="output_files/p2.jpg">
						<img src="output_files/p3.jpg">
						<img src="output_files/p4.jpg">
						<img src="output_files/p5.jpg">
						<img src="output_files/p6.jpg">
			</div>
						<div class="p3"> 
				
				<h1>Want to know more about our menu? </h1>
				<button>Our Menu</button>
				<button>Order Now </button>

		</div>
			<div class="p4">
		<h2>Useful Links            About us </h2> 																		Connect with us 

<br> Home                         We are a team of passionate people whose goal is to improve everyone's<br>        Contact us <br>
<br>    About us                  life through disruptive products. We build great products to solve your<br>       dharmik919@gmail.com <br>
<br>    Products                  business problems.<br>															+91 7046380215 <br>
<br>    Services
<br>    Legal                     Our products are designed for small to medium size companies willing to <br> 
<br>    Privacy Policy            optimize their performance.<br>
<br>    Contact us
			</div>
		</div>
		
			
			
				
	
		
	
    <nav>
		 <ul class="menu"> 
			 <li><a href="#">Home </a></li>
			 <li><a href="http://localhost:8080/new%20project/shop.php">Shops</a></li>
			 <li><a href="#">Events </a></li>
			 <li><a href="#">Services </a></li>
			 <li><a href="#">Pricing </a></li>
			 <li><a href="#">About Us</a></li>
			 <li><a href="#">Contact Us</a></li>
		
			
		 </ul>
		 
		
		
		
	<div class="search">
	<form method="post">
		<input type="text" placeholder="Search...">
		<button type="submit">Contact Us </button>
	</form>
	</div>
    </nav>
 <footer>

 </footer>
    
	
           

</body></html>