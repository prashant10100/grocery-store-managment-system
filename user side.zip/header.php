<html>
<head>
	<link rel="stylesheet" href="header.css">
</head>
<body>
 <nav>
		 <ul class="menu"> 
			 <li><a href="#">Home </a></li>
			 <li><a href="shop.php">Shops</a></li>
			 <li><a href="#">Services </a></li>
			  <li><a href="#">Pricing </a></li>
			 <li><a href="login.php">Login</a></li>
			 <li><a href="about-us.php">Success Stories</a></li>
			 <li><a href="contact-us.php">Contact Us</a></li>
		 </ul> 
		</div>
		
	<div class="search">
	<form method="post">
		<input type="text" placeholder="Search...">
		
		<div class="icon">
			<i class="fa-solid fa-magnifying-glass"></i>
		</div>

		<div class="icon2">
			<i class="fa-regular fa-heart"></i>
		</div>
		
		<div class="icon4">
			<i class="fa-solid fa-cart-shopping"></i>
		</div>
		
		<div class="icon3">
			<i class="fa-solid fa-user"></i>
		</div>
		
	</form>
	</div>
	
	</div>
    </nav>
</body>
</html>