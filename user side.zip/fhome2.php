<?php include("navdemo.php")?>

<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
		 body{
				width: 100%;
		
				text-align: center;
				font-weight: bold;
				background-position: center;
				background-size: cover;		
				overflow-x: hidden;
				background-repeat:no-repeat;
			
		 }

		
		 
	.container{
					width: 100%;
					height: auto;
					
					
			   }
			  
			.container img{
								width: 100%;
								height: 732px;								
						  }
						  
		     .container .text{
								 position: absolute;
								 color: white;
								 left: 50%;
								 top: 60%;
								 transform: translate(-50%,-50%);
								 font-size: 60px;
								 padding-bottom: 100px;
			 }

.f1{
		background-image: url("p3.jpg");
	
		font-size: 6vh;
		justify-content: center;
		text-align: center;
		flex-direction: column;
		justify-content: space-around;
		background-attachment: fixed;
		color: white;
		height: 400px;
		display: block;
		width: 100%;
		background-size: cover;
		padding: 100px;
		padding-top:50px;
}	

.f1 h2{
			margin-top: -10px;
}
 
  .p4 h2{
		height: 550px;
		width: 100%;
  }
  
 
  .hh{
		background-color: white;
  }
  
.p2 {
	margin-top: -80px;
			height: 500px;
			justify-content: space-evenly;
			display: flex;
			margin-bottom: 60px;
}

.p2 .s1{
			height: 100%;
			
			
}

.p2 .s2{
			height: 100%;
		}
		
.p2 .s3{
		
			height: 100%;
		
			
	   }   
			
		nav li{
					padding: 15px;
		}
		
			
		.p1 .k1{
					height: 500px;
					width: 480px;
					margin-left: -850px;

			}		
		
		.p1{
				height: 100px;
				padding-top: 200px;
		}
		
		.h11{
				margin-top: -150px;
				color: dark black;
				font-size: 35px;
				font-family: Wide Latin;
		}
		
		.imageinconteiner{
							width: 25vw;
							height: 50vh;
							margin-top: -250px;
							border-radius: 20px;
						 }
					

		.oursconteiner{
						
							padding: 50px;
		}

  .p3 {
	  	    background-image:url("s4.jpeg");
			color: #f0f3f5;
			height: 150%;
			width: 100%;
			padding: 300px;
			background-repeat: no-repeat;
			background-size: cover;
  }
	
	.h12{
			color: yellow;
	}
	
	button{
				border: none;
				cursor: pointer;
	}
	
	.p3 .yy{
					height: 50px;
					width: 170px;
					border-radius: 500px;
					font-size: 25px;
					
					border-color: #adefd1;
					
				    text-align: center;
				    line-height: 10px;
  }
  
  .p3 button{
				height: 50px;
				width: 170px;
				border-radius: 500px;
				font-size: 25px;
  }
  
		.yy::before{
						content: "";
						height: 3em;
						width: 0;
						border-radius: 30em;
						position: absolute;
						top: -10;
						left: 0;
						transition: .5s ease;
						display: block;
						z-index: -1;
		}

	.yy:hover::before{
						width: 9em;
	}		
	
	.yy{
			z-index: 1;
			box-shadow: 6px 6px 12px #c5c5c5,-6px -6px 12px #ffffff; 
			width: 15em;
			z-index: 1;
			cursor:pointer;
			left: 10px;
	}
 
	.oursback{
				margin: 20px;
	
	}

.h1{

	color: red;
	margin-top: 200px;
}
    </style>
</head>
<body>
<section>
	<div class="container">
		<img src="s3.jpeg">
		<div class="text"><h2>Grocery Heven</h2><br>
		 <h6> A Complete Place For Shopping </h6> 
	</div>
</section>  
<br><br><br><br><br><br><br><br><br><br>
  <div class="oursback">
	<h1 class="h1">Our Best Product</h1>
	<div class="p1">
	  <table>
            <tr>
                <td>
                    <div class="oursconteiner">
                        <img src="b-2.jpeg" class="imageinconteiner"></image>
                        <br><label class="ourscakename">ice colddrink can</label><br>
                          $ 3 
                    </div>
				</td>
				
				<td>
                    <div class="oursconteiner">
                        <img src="b-3.jpeg" class="imageinconteiner"></image>
                        <br><label class="ourscakename">Lays Waffer</label><br>
                          $ 0.5
                    </div>
				</td>
				
				<td>
                    <div class="oursconteiner">
                        <img src="b-4.jpeg" class="imageinconteiner"></image>
                        <br><label class="ourscakename">Dry-Fruit Makhan</label><br>
                          $ 10
                    </div>
				</td>
			
			</tr>
	</table>
        <br>
		</div>
    </div>
			
<br><br><br><br><br><br><br><br><br><br>
	<div class="f1">
		
			<h2>Grocery Heven is not just about products. It's </h2>
			<h2>also about the experience.  </h2>
			
	</div>
	<br><br><br><br><br><br><br><br><br><br>
	<div class="p2">
		<div>	
			<img src="img-9.jpg" class="s3">
		</div>
		<div>	
			<img src="img-13.jpg" class="s1">
		</div>
		<div>
			<img src="img-14.jpg" class="s2">
		</div>
	</div>
		<div class="p3"> 
				
				<h1 class="h11">Want to know more about our menu? </h1>
				<br><br>
				<h1 class="h12">50% OFF</h1>
				<br>
				<h1 class="h12">All Products </h1>
				<br><br>
				<button class="yy">Our Menu</button>
				<button class="yy">Order Now </button>
		</div>
    </style>	
	
	<?php include "team.php"?>

</head>
	  </div>
	</div>
    </div>
</body>
</html>
<?php include("pfooter.php")?>