<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Our Team</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color:rgb(255, 245, 245);
        }
        .team-section {
            text-align: center;
            padding: 50px 20px;
            background-color: black;
        }
        .team-section h1 {
            font-size: 50px;
            color:rgb(234, 113, 13);
            margin-bottom: 10px;
        }
        .team-section p {
            font-size: 25px;
            color: #555;
            margin-bottom: 40px;
        }
        .team-container {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 20px;
        }
        .team-card {
            width: 260px;
            text-align: center;
            background-color:rgb(0, 0, 0);
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.9);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
     
        .team-card img {
            width: 100%;
            height: auto;
            border-radius: 50%;
            margin-top: 15px;
        }
        .team-card:hover{
            border:5px solid  white;
        }
        .team-card h3 {
            font-size: 20px;
            color: #fff;
            margin: 15px 0 5px;
        }
        .team-card p {
            font-size: 16px;
            color: #fdfdfd;
            margin: 0 0 20px;
        }
        .team-card .social-icons {
            display: flex;
            justify-content: center;
            gap: 10px;
            padding: 15px 0;
        }
        .team-card .social-icons a {
            color: #fff;
            font-size: 18px;
            text-decoration: none;
            transition: color 0.3s ease;
        }
        .team-card .social-icons a:hover {
            color: #333;
        }
    </style>
</head>
<body>

<div class="team-section">
    <h1>Our Team</h1>
    <p>Lacus vestibulum sed arcu non sit eros racdi odio euismod.</p>
    <div class="team-container">
        <?php
        $team = [
            ["name" => "Dodiya Dharmik ", "role" => "Owner", "image" => "dimage.png"],
            ["name" => "Prashant Dodeja", "role" => "Owner", "image" => "pimage.png"],
            ["name" => "Willie Hagel", "role" => "Customer Support", "image" => "p7.jpeg"],
            ["name" => "Soraya Rolston", "role" => "Manager", "image" => "p8.jpeg"],
            
        ];

        foreach ($team as $member) {
            echo '<div class="team-card">';
            echo '<img src="' . $member["image"] . '" alt="' . $member["name"] . '">';
            echo '<h3>' . $member["name"] . '</h3>';
            echo '<p>' . $member["role"] . '</p>';
            echo '<div class="social-icons">';
            echo '<a href="#"><i class="fab fa-facebook"></i></a>';
            echo '<a href="#"><i class="fab fa-twitter"></i></a>';
            echo '<a href="#"><i class="fab fa-pinterest"></i></a>';
            echo '<a href="#"><i class="fab fa-youtube"></i></a>';
            echo '</div>';
            echo '</div>';
        }
        ?>
    </div>
</div>

<!-- FontAwesome Icons -->
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>

</body>
</html>
