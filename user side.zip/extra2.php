
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Client Reviews</title>
    <link rel="stylesheet" href="css/c18.css">
</head>
<body>
    <center>
    <div class="maincontainer">
    <div class="custrevcontainer">
        <h1>Client Reviews</h1>
        <p1>At Our Company, we strive to provide the best service possible. Here’s what our clients have to say about us:</p1>
        
        <div class="reviews">
            <div class="review">
                <img src="images/pic1.jpg" alt="Client 1" class="profile-image">
                <h3>John Doe</h3>
                <div class="stars">★★★★★</div>
                <p>"The service was exceptional! I highly recommend them to anyone looking for quality work."</p>
            </div>
            <div class="review">
                <img src="images/pic2.jpg" alt="Client 2" class="profile-image">
                <h3>Jane Smith</h3>
                <div class="stars">★★★★☆</div>
                <p>"Great experience overall. The team was professional and attentive to my needs."</p>
            </div>
            <div class="review">
                <img src="images/pic3.jpg" alt="Client 3" class="profile-image">
                <h3>Michael Johnson</h3>
                <div class="stars">★★★★★</div>
                <p>"I was blown away by the quality of service. Will definitely be coming back!"</p>
            </div>
            <div class="review">
                <img src="images/pic4.jpg" alt="Client 4" class="profile-image">
                <h3>Emily Davis</h3>
                <div class="stars">★★★★☆</div>
                <p>"Very satisfied with the results. The staff was friendly and helpful."</p>
            </div>
            <div class="review">
                <img src="images/pic6.jpg" alt="Client 5" class="profile-image">
                <h3>David Wilson</h3>
                <div class="stars">★★★★★</div>
                <p>"Top-notch service! I couldn't ask for more. Highly recommend!"</p>
            </div>
            <div class="review">
                <img src="images/pic-7.png" alt="Client 6" class="profile-image">
                <h3>Sarah Brown</h3>
                <div class="stars">★★★☆☆</div>
                <p>"Good service, but there is room for improvement. Overall, a decent experience."</p>
            </div>
        </div>
    </div>
    </div>
    </center>
</body>
</html>
