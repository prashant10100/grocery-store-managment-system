<?php

include "database.php";


$user =  $_SESSION['user'];
if (isset($_POST['update'])) {
    $update_value = $_POST['update_quntity'];
    // echo $update_value;
    $update_id = $_POST['update_quantity_id'];
    // echo $update_id;
    $update = mysqli_query($conn, "UPDATE `cart` SET `quantity`='$update_value' WHERE  `id`='$update_id'");

}

if (isset($_GET['remove'])) {
    $remove = $_GET['remove'];
    $q = mysqli_query($conn, "delete from cart where id=$remove") or die("not deleted");
    header("location:cart.php");

}

if (isset($_POST['alldelete'])) {

    $q = mysqli_query($conn, 'delete from cart') or die("not deleted");
    //  header("location:cart.php");
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        .cartbody {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f2f2f2;
        }

        h2 {
            margin-top: 30px;
            text-align: center;
            font-size: xxx-large;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
        }

        th,
        td {
            padding: 15px;
            text-align: center;
            border: 1px solid #ccc;
        }

        th {
            background-color: #2c7373;
            color: white;
        }

        .imgsize {
            width: 100px;
        }

        input,
        .update {
            height: 30px;
            padding: 5px;

        }

        .update {
            height: 30px;
            background-color: orange;
            border: 1px solid orange;
        }

        .cart-actions {
            display: flex;
            justify-content: space-between;
            background: #002b2b;
            padding: 18px;
        }

        .cart-actions button {
            padding: 10px 20px;
            border: none;
            cursor: pointer;
            font-size: 16px;
        }

        .delete-btn {
            background: #002b2b;
            color: white;
            height: 40px;
            margin-top: 10px;
            color: red;
        }

        .checkout-btn,.checkatag {
            background: #008c8c;
            color: white;
            text-decoration:none;
        }

        .continue-btn {
            background: #00b3b3;
            color: white;
        }

        .total-box {
            background: #a2e6e6;
            padding: 10px;
            font-size: 18px;
            font-weight: 700;
        }

        .remove-btn {
            color: blue;
            text-decoration: underline;
            cursor: pointer;
        }

        .empty {
            background-color: #008c8c;
            height: 50px;
            align-items: center;
            display: flex;
            justify-content: center;
            font-size: 30px;
        }
    </style>
</head>

<body>
    <?php include "for nav call4.php"; $grand_total = 0;?>
    <div class="cartbody">

    <h2>My Cart</h2>
    <table>
        <?php
        $query = mysqli_query($conn, "select * from cart where uid='$_SESSION[username]'");
        if (mysqli_num_rows($query) > 0) {
            echo "
                <tr>
                    <th>Sl No</th>
                    <th>Product Name</th>
                    <th>Product Image</th>
                    <th>Product Price</th>
                    <th>Product Quantity</th>
                    <th>Total Price</th>
                    <th>Action</th>
                </tr>";
            $num = 1;
            $grand_total = 0;
            while ($data = mysqli_fetch_assoc($query)) {

                ?>
                <tr>
                    <td><?php echo $num ?></td>

                    <td><?php echo $data['name'] ?></td>

                    <td> <img src="Admin/images/addproduct/<?php echo $data['image']; ?>" class="imgsize"></td>
                    <td>₹<?php echo $data['price'] ?></td>

                    <td>
                        <form action="" method="post">
                            <input type="hidden" value=<?php echo $data['id'] ?> name="update_quantity_id">
                            <input type="number" min="1" value=<?php echo $data['quantity'] ?> name="update_quntity">
                            <button type="submit" class="update" name="update">Update</button>
                        </form>
                    </td>

                    <?php $total = number_format($data['price'] * $data['quantity']); ?>
                    <td>₹<?php echo $total ?>/-</td>

                    <td><span class="remove-btn">
                            <a href="cart.php?remove=<?php echo $data['id'] ?>"
                                onclick="return confirm('Are you sure you want to delete This Item')">
                                <!-- <img src="images/deleteicon.png" alt="" height="40px"> -->delete
                            </a></span></td>
                </tr>

                <?php
                //$grand_total=$grand_total+$total;
             $grand_total = $grand_total + ($data['price'] * $data['quantity']);
                $num++;

                //$grand_total=$grand_total+($data['quantity']*$data['price']);
               
            }
        } 
        else
         { ?>

            <div class="empty">Your Cart is Empty</div>
            <?php
        }
        ?>  

    </table>
    <?php



 if ($grand_total > 0) {
                    ?>
                    <form action="" method="post">
                        <div class="cart-actions">
                            <a href=""> <button class="continue-btn">Continue Shopping</button></a>
                            <div class="total-box">Grand_total=₹<?php echo $grand_total; ?></div>
                            <button class="checkout-btn"><a href="order.php" class="checkatag">Proceed to checkout</a></button>
                        </div>
                        <button type="submit" class="delete-btn" name="alldelete"
                            onclick="return confirm('Are you sure you want to delete This Item')">Delete All</button>
                    </form>
                    <?php
                }?>
</div>
</body>
</html>