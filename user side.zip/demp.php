body {
    margin: 0;
    font-family: Arial, sans-serif;
}

.navbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    background-color: #003366; /* Dark blue background */
    padding: 10px 20px;
}

.logo img {
    height: 50px; /* Adjust logo size */
}

.nav-links ul {
    list-style: none;
    display: flex;
    margin: 20px;
    padding: 0;
}

.nav-links li {
    margin: 0 15px;
}

.nav-links a {
    color: white;
    text-decoration: none;
    font-weight: bold;
}

/* .nav-links a:hover {
    text-decoration: underline;
} */

.search-container {
    flex-grow: 1;
    display: flex;
    justify-content: center;
}

.search-bar {
    border: none;
    border-radius: 20px; /* Attractive curve */
    padding: 10px;
    width: 300px; /* Adjust width as needed */
    outline: none; /* Remove outline on focus */
    margin-left: -10px;
}

.icons {
    display: flex;
    align-items: center;
    justify-content: space-evenly;
}

.icon {
    margin-left: 15px;
}

.icon img {
    height: 25px; /* Adjust icon size */
}
.searchicon{
    margin-right: 180px;
    
}