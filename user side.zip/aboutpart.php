<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Unique Flavors Spices</title>
    <link rel="stylesheet" href="css/aboutpart.css">
</head>
<body>
    <div class="container">
        <h1 class="title">Unique flavors spices</h1>
        <p class="subtitle">Quisque volutpat mattis eros.</p>
        <div class="stars">
            <span>⭐</span>
            <span>⭐</span>
        </div>
        <div class="features">
            <?php
            $features = [
                ["icon" => "☕", "title" => "Flavors", "desc" => "Sed vestibulum nulla elementum auctor tincidunt. Aliquam sit amet cursus mauris. Sed vitae mattis ipsum."],
                ["icon" => "🌍", "title" => "Export", "desc" => "Sollicitudin ac hendrerit nec, tempor quis nisl. Sed vestibulum nulla elementum auctor tincidunt."],
                ["icon" => "👤", "title" => "Cultivation", "desc" => "Vestibulum enim nulla, sollicitudin ac hendrerit nec, tempor quis nisl."],
               
            ];
            foreach ($features as $feature) {
                echo "
                <div class='feature'>
                    <div class='icon'>{$feature['icon']}</div>
                    <h3 class='feature-title'>{$feature['title']}</h3>
                    <p class='feature-desc'>{$feature['desc']}</p>
                </div>
                ";
            }
            ?>
        </div>
    </div>
</body>
</html>
