<?php
$conn = mysqli_connect("localhost", "root", "", "onlinegrocery");

$mname = $mlname = $mmno = $mdob = $mg = $memail = $musername = $mpassword = $mcity = "";
$error = 0;
$name = $mno = $dob = $g = $email = $username = $city = "";
if (isset($_POST["submit"])) {
    $name = $_POST["name"];
    $mno = $_POST["mno"];
    $dob = $_POST["dob"];
    $g = $_POST["g"];
    $email = $_POST["email"];
    $username = $_POST["username"];
    $password = $_POST["password"];
    $city = $_POST["city"];

    if ($name == "") {
        $mname = "Please Enter your Name !!";
        $error++;
    } else {
        $names = "/^[A-Za-z]+$/";
        if (!preg_match($names, $name)) {
            $mname = "Please Enter valid Name !!";
            $error++;
        }
    }
    if ($mno == "") {
        $mmno = "Please Enter your Mobile Number !!";
        $error++;
    } else {
        $mnos = "/^[0-9]+$/";
        if (!preg_match($mnos, $mno)) {
            $mmno = "Please Enter valid Mobile No. !!";
            $error++;
        } else {
            $mnolen = strlen($mno);
            if ($mnolen < 10) {
                $mmno = "It required minimum 10 Digits !!";
                $error++;
            } elseif ($mnolen > 10) {
                $mmno = "It required maximum 10 Digits !!";
                $error++;
            }
        }
    }
    if ($dob == "") {
        $mdob = "Please Enter your Date of Birth !!";
        $error++;
    }
    if ($g == "") {
        $mg = "Please Select your Gender !!";
        $error++;
    }
    if ($email == "") {
        $memail = "Please Enter your E-mail Id !!";
        $error++;
    } else {
        $emails = "/^[a-z0-9]@[a-z].[a-z]+$/";
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $memail = "Please Enter valid E-mail Id !!";
            $error++;
        }
    }
    if ($username == "") {
        $musername = "Please Enter your Username !!";
        $error++;
    } else {
        $usernames = "/^[A-Za-z0-9]+$/";
        if (!preg_match($usernames, $username)) {
            $musername = "Combination of [A-Z],[a-z] and [0-9] !!";
            $error++;
        }
    }
    if ($password == "") {
        $mpassword = "Please Enter your Password !!";
        $error++;
    } else {
        $passwords = "/^[A-Za-z0-9]+$/";
        if (!preg_match($passwords, $password)) {
            $mpassword = "Combination of [A-Z],[a-z] and [0-9] !!";
            $error++;
        } else {
            $passwordlen = strlen($password);
            if ($passwordlen < 8) {
                $mpassword = "It required minimum 8 character !!";
                $error++;
            } elseif ($passwordlen > 12) {
                $mpassword = "It require maximum 12 character !!";
                $error++;
            }
        }
    }
    if ($city == "") {
        $mcity = "Please Enter your City !!";
        $error++;
    } else {
        $cities = "/^[A-Za-z]+$/";
        if (!preg_match($cities, $city)) {
            $mcity = "Please Enter valid City Name !!";
            $error++;
        }
    }

    if ($error == 0) {
        $sql = "select * from registration where username = '$username' and password = '$password' or email = '$email' and password = '$password'";
        $result = mysqli_query($conn, $sql);
        echo $check = mysqli_num_rows($result);

        if ($check >= 1) {
            echo "<script>";
            echo "alert('User already Registered')";
            echo "</script>";
        } else {
            $sql = "insert into registration values(id,'$name',$mno,'$dob','$city','$g','$email','$username','$password')";
            $result = mysqli_query($conn, $sql);
            if ($result) {
                echo "<center>";
                echo "<div class='success' id='s'>";
                echo "Registration Successfull" . "<br>";
                echo "<input type='button' name='successok' value='OK' id='sok' class='successok'>";
                echo "</div>";
                echo "</center>";
            } else {
                echo "<center>";
                echo "<div class='unsuccess' id='u'>";
                echo "Registration Unsuccessfull" . "<br>";
                echo "<input type='button' name='unsuccessok' value='OK' id='uok' class='unsuccessok'>";
                echo "</div>";
                echo "</center>";
            }
        }
    }
}

?>
<html>

<head>
    <style>
        .mainform {
            margin-top: 50px;
            width: fit-content;
            text-align: left;
            padding: 50px;
            padding-top: 20px;
            padding-bottom: 20px;
            box-shadow: 0px 0px 15px black;
            border-radius: 10px;
        }

        .reglabel {
            font-size: 2.5rem;
            font-weight: 600;
            line-height: 3rem;
            margin: 200px;
            color: #fd0155;
            font-family: Arial, Helvetica, sans-serif;
        }

        .label {
            font-size: 1rem;
            line-height: 2rem;
            font-weight: 550;
            color: #07074d;
        }

        .gender {
            background: none;
        }

        .reginput {
            width: 600px;
            height: 41px;
            padding-left: 7.5px;
            font-family: 'Times New Roman', Times, serif;
            font-size: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background: none;
        }

        .reginput:hover {
            border-color: royalblue;
        }

        .show {
            position: relative;
            margin-left: -55px;
            color: royalblue;
            font-size: 18px;
            font-family: 'Times New Roman', Times, serif;
        }

        .submit,
        .reset {
            margin-top: 10px;
            color: #fff;
            height: 45px;
            width: 100px;
            border: none;
            font-weight: 600;
        }

        .submit:hover {
            border-radius: 5px;
            background-color: #1a47a8;
        }

        .reset:hover {
            border-radius: 5px;
            background-color: rgb(190, 59, 12);
        }

        .submit {
            background-color: #2563eb;
        }

        .reset {
            background-color: orangered;
        }

        /* Sign in link */
        .signinlabel {
            font-size: 1rem;
            font-weight: 700;
            line-height: 3rem;
        }

        .signinlink {
            color: #2563eb;
            text-decoration: none;
        }

        .signinlink:hover {
            color: #0651f3;
            text-decoration: underline;
        }

        .red {
            color: red;
        }

        /* Success Unsuccess */
        .success,
        .unsuccess {
            position: absolute;
            margin-top: 20vh;
            margin-left: 40%;
            width: 20vw;
            text-align: center;
            border-radius: 5px;
            height: 25vh;
            padding-top: 10vh;
            font-size: 2rem;
            background-color: #fff;
        }

        .success {
            color: green;
            border: 0.1px solid green;
        }

        .unsuccess {
            color: red;
            border: 0.1px solid red;
        }

        .successok {
            margin-top: 5vh;
            color: whitesmoke;
            background-color: green;
            border: none;
            width: 10vw;
            height: 5vh;
        }

        .unsuccessok {
            margin-top: 5vh;
            color: whitesmoke;
            background-color: red;
            border: none;
            width: 10vw;
            height: 5vh;
        }

        @media (max-width:600px) {
            .rimage {
                width: 100%;
                height: 50vh;
                padding: 0;
                margin: 0;
            }

            .h1label {
                padding-left: 20vw;
            }

            .input {
                width: 35vw;
                height: 5vh;
                font-family: 'Times New Roman', Times, serif;
                font-size: 15px;
                justify-content: center;
            }

            .submit,
            .reset {
                margin-top: 10px;
                color: #fff;
                height: 6vh;
                width: 15vw;
                border: none;
                font-weight: 600;
            }

            .mainform {
                padding-top: 5vh;
                width: 85%;
                margin-left: 10vw;
            }

            .form1div {
                width: 46%;
            }

            .form2div {
                margin-left: 0;
                padding-left: 0;
                width: 50%;
            }

            .signinlabel {
                padding-left: 15vw;

            }

        }
    </style>
</head>

<body class="registerbody">
    <form method="post">
        <center>
            <div class="mainform">

                <label class="reglabel">Registration</label><br>
                <label class="label">Name<b class="red">*</b> </label><br>
                <input type="text" name="name" placeholder="Enter your Name" class="reginput" value="<?php echo $name; ?>">
                <br><label class="red"><?php echo $mname; ?></label>
                <br>

                <label class="label">Mobile No.<b class="red">*</b> </label><br>
                <input type="text" name="mno" placeholder="Enter your Mobile Number" class="reginput" value="<?php echo $mno; ?>">
                <br><label class="red"><?php echo $mmno; ?></label>
                <br>

                <label class="label">Date of Birth<b class="red">*</b> </label><br>
                <input type="date" name="dob" class="reginput" value="<?php echo $dob; ?>">
                <br><label class="red"><?php echo $mdob; ?></label>
                <br>

                <label class="label">City<b class="red">*</b> </label><br>
                <input type="text" name="city" placeholder="Enter your City" class="reginput" value="<?php echo $city; ?>">
                <br><label class="red"><?php echo $mcity; ?></label><br>

                <label class="label">Gender<b class="red">*</b> </label><br>
                <input type="radio" name="g" class="gender" value="Male" checked>Male
                <input type="radio" name="g" class="gender" value="Female">Female
                <br><label class="red"><?php echo $mg; ?></label>
                <br>




                <label class="label">E-mail<b class="red">*</b> </label><br>
                <input type="text" name="email" placeholder="Ex - abc123@gmail.com" class="reginput" value="<?php echo $email; ?>">
                <br><label class="red"><?php echo $memail; ?></label>
                <br>

                <label class="label">Username<b class="red">*</b></label><br>
                <input type="text" name="username" placeholder="Enter your Username" class="reginput" value="<?php echo $username; ?>">
                <br><label class="red"><?php echo $musername; ?></label>
                <br>

                <label class="label">Password<b class="red">*</b> </label><br>
                <input type="password" name="password" id="password" placeholder="Enter your Password" class="reginput"> <a id="show" class="show">Show</a>
                <br><label class="red"><?php echo $mpassword; ?></label>
                <br>


                <center><input type="submit" name="submit" value="Submit" id="sub" class="submit"> <input type="reset" value="Reset" class="reset"><br>

                    <br><label class="signinlabel">Already have an Account? <a class="signinlink" href="loginr.php">Sign in</a></label>
                </center>

            </div>
        </center>
    </form>
</body>

</html>
<script src="javascript/registration.js"></script>
<?php include("footer.php"); ?>
<script>
    let sok = document.querySelector("#sok");
    let s = document.querySelector("#s");
    let show = document.querySelector("#show");
    let pass = document.querySelector("#password");

    show.onclick = function() {
        if (pass.type == "password") {
            show.text = "Hide"
            pass.type = "text"
        }
        else
        {
            show.text = "Show"
            pass.type = "password"
        }
    }

    sok.onclick = function() {
        s.style.display = "none";
    }
</script>