<?php
session_start();
include("database.php");
error_reporting(0);
$pid = $_GET['id'];

// Fetch product details
$sql = "SELECT * FROM addproduct WHERE id = $pid";
$result = mysqli_query($conn, $sql);

if (!$result) {
    // die("Error: " . mysqli_error($conn)); // Debugging
}

$rpro = mysqli_fetch_assoc($result);

// Sanitize session variable
$user = mysqli_real_escape_string($conn, $_SESSION['user']);

// Check if product is already in wishlist
$sql = "SELECT * FROM wishlist WHERE uid = '$_SESSION[username]' AND name = '{$rpro['iname']}'";
$res = mysqli_query($conn, $sql);

if (!$res) {
    die("Error: " . mysqli_error($conn)); // Debugging
}

if (mysqli_num_rows($res) > 0) {
    echo "<script>alert('Product already added to wishlist');</script>";
} else {
    $q = "INSERT INTO wishlist (uid, name, price, image) 
          VALUES ('$_SESSION[username]', '{$rpro['iname']}', '{$rpro['price']}', '{$rpro['image']}')";
    $r = mysqli_query($conn, $q);

    if ($r) {
        echo "<script>alert('Product added to wishlist successfully');</script>";
    } else {
        echo "<script>alert('Error adding product to wishlist: " . mysqli_error($conn) . "');</script>";
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wishlist</title>
    <style>
       body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f8f9fa;
}

h2 {
    background-color: #2563eb;
    color: white;
    padding: 15px;
    text-align: center;
    font-size: 24px;
    font-weight: bold;
}

.wishlist-container {
    width: 80%;
    margin: 20px auto;
    background: white;
    padding: 20px;
    box-shadow: 0px 2px 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
}

.wishlist-item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 15px;
    border-bottom: 1px solid #ddd;
}

.wishlist-item:last-child {
    border-bottom: none;
}

.wishlist-item img {
    width: 150px;
    height: 150px;
    object-fit: contain;
    margin-right: 50px;
}

.wishlist-item-info {
    flex-grow: 1;
}

.wishlist-item-info p {
    margin: 3px 0;
    font-size: 14px;
    color: #333;
}

.wishlist-item-info p:first-child {
    font-weight: bold;
}

.wishlist-item-buttons {
    display: flex;
    gap: 10px;
}

.wishlist-item-buttons button {
    padding: 6px 10px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 14px;
    color: white;
}

.wishlist-item-buttons .remove {
    background-color: #dc3545;
    color:white;
    text-decoration: none;
    padding: 10px;
    border-radius: 5px;
}

.wishlist-item-buttons .move-to-cart {
    background-color: #2563eb;
}

.wishlist-item-buttons .remove:hover {
    background-color: #c82333;
}

.wishlist-item-buttons .move-to-cart:hover {
    background-color: #1d4ed8;
}

.continue-shopping {
    display: block;
    margin: 20px auto;
    padding: 10px 15px;
    background-color: #ffffff;
    border: 1px solid #ccc;
    cursor: pointer;
    font-size: 14px;
}

.continue-shopping:hover {
    background-color: #f1f1f1;
}
    </style>
</head>
<body>
    <h2>Your Wishlist</h2>
    <div class="wishlist-container">
        <?php
        $sql = "SELECT * FROM wishlist WHERE uid = '$_SESSION[username]'";
        $result = mysqli_query($conn,$sql);
        
        if ($result->num_rows > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
              
                echo "<div class='wishlist-item'>";
                echo "<img src='Admin/images/addproduct/{$row['image']}' alt='Item Image'>";
                echo "<div class='wishlist-item-info'>";
                echo "<p>{$row['name']}</p>";
                echo "<p>Price: Rs. {$row['price']}</p>";
                echo "</div>";
                echo "<div class='wishlist-item-buttons'>";
                echo "<a href='removewish.php?id=$row[id]' class='remove'>Remove</a>";
                echo "<button class='move-to-cart'>Add to Cart</button>";
                echo "</div>";
                echo "</div>";
            }
        } else {
            echo "<p>No products in your wishlist.</p>";
        }
        
        // Close the connection
        $conn->close();
        ?>
    </div>
</body>
</html>