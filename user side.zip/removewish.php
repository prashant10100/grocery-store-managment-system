<?php
    include("database.php");
    $id = $_GET['id'];
    $sql = "delete from wishlist where id=$id";
    $result = mysqli_query($conn,$sql);
    if($result)
    {
        ?>
        <script>
            alert("Product removed from wishlist");
            window.location.href = "wishlist.php";
        </script>
        <?php
    }
?> 