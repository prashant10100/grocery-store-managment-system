<?php 
error_reporting(0);
include("for nav call4.php");



$conn = mysqli_connect("localhost", "root", "", "onlinegrocery");

if(isset($_POST['sub']))
{
        
    $name=$_POST['name'];
    $email=$_POST['email'];
    $number=$_POST['number'];
    $message=$_POST['message'];

    
    echo    $query="insert into contect values(id,'$name','$email','$number','$message')";
        
        $result=mysqli_query($conn,$query);
        if($result)
        {
            ?>
             
            
            <?php
        }
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url("adminimg.jpg");
            background-repeat: no-repeat;
            background-size: cover;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .contact-form {
            background: white;
            padding: 20px 30px;
            border: 1px solid #ddd;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            margin-left: 500px;
            padding-top: 80px;
        }
        .contactcontainer{
            padding-top: 180px;
        }

        .contact-form h1 {
            font-size: 24px;
            margin-bottom: 20px;
            text-align: center;
        }

        .contact-form input,
        .contact-form textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
        }

        .contact-form textarea {
            resize: none;
            height: 100px;
        }

        .contact-form button {
            width: 100%;
            padding: 10px;
            background-color: #28a745;
            border: none;
            border-radius: 4px;
            color: #ffffff;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .contact-form button:hover {
            background-color:rgb(63, 66, 64);
        }

        h1{
            margin-top: -20px;
        }
    </style>
</head>
<body>
<div class="contactcontainer">
<!-- <form action="https://api.web3forms.com/submit" method="POST" class="contact-form"> -->

    <form action="https://api.web3forms.com/submit" method="POST" class="contact-form">
        <h1>Get in Touch</h1>
        <input type="hidden" name="access_key" value="de697f0a-465a-4849-b042-181c1cf28da6">
        

        <input type="text" name="name" placeholder="Enter your name" required>
        <input type="email" name="email" placeholder="Enter your email" required>
        <input type="text" name="number" placeholder="Enter your number" required>
        <textarea name="message" placeholder="Enter your message" required></textarea>
        <button type="submit" name="submit">Send Message</button>
    </form>
</div>
</body>
</html>

<?php include("pfooter.php"); ?>