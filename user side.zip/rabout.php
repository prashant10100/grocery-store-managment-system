<?php 
error_reporting(0);
include("for nav call4.php");


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - Grocery Heaven</title>
    <style>
        body {
            font-family: 'Verdana', sans-serif;
            margin: 0;
            padding: 0;
            /* background: #f3f4ed; */
            color: #333;
        }
     
    
        .containermain {
           padding-top: 150px;
            width: 1500px;
            margin: 0 auto;
        }
        .section {
            margin-bottom: 50px;
        }
        .section h2 {
            font-size: 2.8rem;
            color: #ff4500;
            margin-bottom: 20px;
            text-transform: uppercase;
        }
        .section img {
            max-width: 100%;
            height: auto;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .two-columns {
            display: flex;
            flex-wrap: wrap;
            gap: 30px;
        }
        .column {
            flex: 1;
            min-width: 300px;
        }
        .highlight {
            color: #ff7f50;
            font-weight: bold;
        }
        .achievements {
            background: #fef9e7;
            padding: 30px;
            border-radius: 15px;
            border: 2px solid #ff4500;
        }
       

        header {
            text-align: center;
            padding: 2rem;
            background-color: #f4f4f4;
            padding-top: 50pxs;
        }

        header img {
            max-width: 100%;
            height: auto;
            margin: 1rem 0;
        }

        section {
            padding: 2rem;
            margin: 0 auto;
            max-width: 1500px;
        }

        .section-title {
            text-align: center;
            margin-bottom: 2rem;
            font-size: 1.8rem;
            color: #8B4513;
        }
        h3{
            color:  #ff4500;
            font-size: 30px;
        }

       

        .features {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 1rem;
        }

        .feature {
            flex: 1 1 calc(25% - 1rem);
            background-color: #ffe4b5;
            padding: 1rem;
            border-radius: 5px;
            text-align: center;
        }

        .feature img {
            max-width: 50px;
            margin-bottom: 1rem;
        }

        .image-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 2rem;
        }

        .image-content img {
            max-width: 48%;
            height: auto;
            border-radius: 5px;
        }

        .content {
            max-width: 50%;
        }
        
            /* .afooter{
                width: 1500px;
                margin-left: -180px;
            } */
       

    </style>

    </style>
</head>
<body>
   

    <div class="containermain">
        <!-- Why Choose Us and Work of It -->
        <div class="section two-columns">
            <div class="column">
                <h2>Why Choose Us?</h2>
                <p><span class="highlight">Grocery Heaven</span> is your trusted partner for all your grocery needs. With an unwavering commitment to quality and convenience, we strive to make every shopping experience delightful. We offer:</p>
                <ul>
                    <li>A vast range of fresh and organic products.</li>
                    <li>Competitive prices that suit every budget.</li>
                    <li>Seamless online ordering and fast delivery.</li>
                    <li>Exclusive deals and discounts just for you.</li>
                </ul>
                <p>Choose <span class="highlight">Grocery Heaven</span> and enjoy a blend of modern convenience and traditional quality!</p>
              
            </div>
            <div class="column">
                <h2>Work of It</h2>
                <p>At <span class="highlight">Grocery Heaven</span>, we have a dedicated team working behind the scenes to deliver exceptional service. Here’s what we do:</p>
                <ul>
                    <li>Partner with local farmers to bring fresh produce directly to you.</li>
                    <li>Implement eco-friendly practices to reduce our carbon footprint.</li>
                    <li>Streamline operations for efficient service and minimal delays.</li>
                </ul>
                <p>We believe in creating a sustainable and impactful grocery ecosystem that benefits both customers and communities.</p>
                
            </div>
        </div>

        <!-- Success Stories -->
        <div class="section">
            <h2>Success Stories</h2>
            <p>Over the years, <span class="highlight">Grocery Heaven</span> has grown from a small idea to a household name, thanks to our loyal customers and dedicated team. Here are a few milestones that define our journey:</p>
            <ul>
                <li>We have served over 5 million happy customers nationwide.</li>
                <li>Partnered with 800+ local farmers and suppliers.</li>
                <li>Consistently rated as the top grocery delivery service in India.</li>
            </ul>
            
        </div>

        <!-- How It Opened -->
        <div class="section">
            <h2>How It All Began</h2>
            <p>In 2012, a small team of passionate individuals came together with a mission: to make grocery shopping hassle-free. Starting from a single warehouse in Bangalore, <span class="highlight">Grocery Heaven</span> quickly expanded to cover multiple cities across India. Our journey has been one of innovation, hard work, and an unwavering dedication to customer satisfaction.</p>
        </div>
        <?php include("extra2.php")?>
        <header>
        <h1>The Richest Spices in the World</h1>
        <img src="images/pic-1.jpg" alt="Assorted spices">
        <p>Quisque volutpat mattis eros. Nullam malesuada erat ut ki diaml ka dhuddu pochu turpis. Suspendisse urna nibh, viverra non, semper suscipit, posuere a, pede. Donec nec justo eget felis facilisis fermentum. Morbi in sem quis dui placerat ornare. Pellentesque odio nisi, euismod in, pharetra a, ultricies in, diam. Sed arcu. Cras consequat</p>
    </header>

<?php include("aboutpart.php")?>

    <section>
        <h2 class="section-title">A Unique Blended Taste</h2>
        <div class="image-content">
            <div class="content">
                <h3>The finest spice</h3>
                <p>Donec arcu purus, euismod nec eleifend et, luctus efficitur erat. Pellentesque at justo porttitor quis ornare ante integer quis ornare ante. Phasellus vel aliquam libero. Donec arcu purus, euismod nec eleifend et, luctus efficitur erat. Pellentesque at justo porttitor quis ornare ante integer quis ornare ante. Phasellus vel aliquam libero.</p>
            </div>
            <img src="images/pic-2.jpg" alt="Assorted spices in bowls">
        </div>

        <div class="image-content">
            <img src="images/pic-3.jpg" alt="Spices in sacks">
            <div class="content">
                <h3>The premium flavor</h3>
                <p>Pellentesque at justo porttitor quis ornare ante integer quis ornare ante. Phasellus vel aliquam libero. Donec arcu purus, euismod nec eleifend et, luctus efficitur erat. Pellentesque at justo porttitor quis ornare ante integer quis ornare ante. Phasellus vel aliquam libero. Donec arcu purus, euismod nec eleifend et, luctus efficitur erat.</p>
            </div>
        </div>
    </section>
<div class="afooter">
<?php include("vaveabout.php"); ?>
</div>

       </body>
</html>
