<?php 
error_reporting(0);
include("for nav call4.php");

if(!$_SESSION["username"])
{

  ?>
  <script>
    location.href = "login.php";
  </script>
  <?php
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="special.css">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
    <center><label class="our">Our Best Product</label></center>
    <div class = containero>
      <div class = cardo>
        <div class = imageo>
          <img href = "#" src = "images/b-2.jpeg">
        </div>
        <div class = contento>
          <h3>The Ice-cold Drink</h3>
          <p>In Summer The Ice-Cold Drink is our Top Selling Product,           The Demand Of It Is Verry High                It Is our 1'st top sell Item.</p>
        </div>
      </div>    
      <div class = cardo>
        <div class = imageo>
          <img href = "#" src = "images/b-4.jpeg">
        </div>
        <div class = contento>
          <h3>The Rosted Makhana </h3>
          <p>The Rosted Makhana Is All time Sell Item ,           During Winter The Demand Of It Is Verry High               It Is our 2'st top sell Item.</p>
        </div>
      </div>   
      <div class = cardo>
        <div class = imageo>
          <img href = "#" src = "images/c13.jpg">
        </div>
        <div class = contento>
          <h3>Dairy-Milk Fruit And Nuts</h3>
          <p>Dairy-Milk Fruit And Nuts Is Most Sell On Special Days,         During Valantine Week The Demand Of It Is Verry High          It Is our 3'st top sell Item.</p>
        </div>
      </div>   
      
    </div>  


    <center><label class="hearbs">Special Hearbs</label></center>
    <div class = containero>
      <div class = cardo>
        <div class = imageo>
          <img href = "#" src = "images/sp/1.jpeg">
        </div>
        <div class = contento>
          <h3>Turmeric Powder</h3>
          <p>In Turmeric Powder Is Our Special Authentic Hearb ,           This Made By The Authentic Proess                 It's Our Top Sell Special Hearbs.</p>
        </div>
      </div>    
      <div class = cardo>
        <div class = imageo>
          <img href = "#" src = "images/sp/2.jpeg">
        </div>
        <div class = contento>
          <h3>Asafoetida Powder</h3>
          <p>The Asafoetida Powder is a One Of Special Hearb ,          The demand Of It Is High IN All Season               It Is verry Good For Body.</p>
        </div>
      </div>   
      <div class = cardo>
        <div class = imageo>
          <img href = "#" src = "images/sp/3.jpeg">
        </div>
        <div class = contento>
          <h3>Cardamom</h3>
          <p>The Cardamom Is Also Known As Eliaychi,         During cold Time The Demand Of it IS veery High          This Is use In Many Things.</p>
        </div>
      </div>   
      
    </div>


    <center><label class="winter">Top Seller Of Winter</label></center>
    <div class = containero>
      <div class = cardo>
        <div class = imageo>
          <img href = "#" src = "images/sp/4.jpeg">
        </div>
        <div class = contento>
          <h3>Amul Ghee</h3>
          <p>In Winter The Use Of Ghee Is high,           The sell Of Amul Ghee IS Verry High Specialy In Winter                Ghee Is Verry Good TO Our Emunity System.</p>
        </div>
      </div>    
      <div class = cardo>
        <div class = imageo>
          <img href = "#" src = "images/sp/5.jpeg">
        </div>
        <div class = contento>
          <h3>Almonds </h3>
          <p>The Almond Is One OF The Most FAvuirot Dry-Fruit,           During Winter The Demand Of Almond Is Verry High               Almond Proide Good Streaingth For Mind.</p>
        </div>
      </div>   
      <div class = cardo>
        <div class = imageo>
          <img href = "#" src = "images/sp/6.jpg">
        </div>
        <div class = contento>
          <h3>Caratos</h3>
          <p>Caratoes Are Most Use In Winter,        The Caratos Are Used In MAny Things           The caratos Are Use For Gajar Halva.</p>
        </div>
      </div>   
      
    </div>


    <center><label class="summer">Top Seller Of Summer</label></center>
    <div class = containero>
      <div class = cardo>
        <div class = imageo>
          <img href = "#" src = "images/sp/7(2).jpeg">
        </div>
        <div class = contento>
          <h3>Cocacola</h3>
          <p>In Summer The CocaCola is our Top Selling Product,           The Demand Of It Is Verry High                In HOt Whether It Drinks Most.</p>
        </div>
      </div>    
      <div class = cardo>
        <div class = imageo>
          <img href = "#" src = "images/sp/8.jpg">
        </div>
        <div class = contento>
          <h3>Mango Fruit </h3>
          <p>The Mango Fruit IS Specialy Come In Summer,           Mango Is Use in Verry Things                Mango IS one Of The Most Sell Fruit.</p>
        </div>
      </div>   
      <div class = cardo>
        <div class = imageo>
          <img href = "#" src = "images/sp/9.jpeg">
        </div>
        <div class = contento>
          <h3>Amul Lassi</h3>
          <p>Amul Lassi Is One Of Most Drink In Summer,         During Summer The Demand Of It Is Verry High          It HElps To MAintain Our Body Highdrated.</p>
        </div>
      </div>   
      
    </div>


    <center><label class="monsoon">Top Seller Of Monsoon</label></center>
    <div class = containero>
      <div class = cardo>
        <div class = imageo>
          <img href = "#" src = "images/sp/10.jpeg">
        </div>
        <div class = contento>
          <h3>Fortune Besan</h3>
          <p>The Fortune Besan IS Use Verry High In Monsoon,           It IS Use To Make Many Dishes                The Fortune Besan is 100% pure. .</p>
        </div>
      </div>    
      <div class = cardo>
        <div class = imageo>
          <img href = "#" src = "images/sp/11.jpeg">
        </div>
        <div class = contento>
          <h3>Red-label Tea</h3>
          <p>In Cold Whether The USe OF Tea Is High,           Compaire To Other Tea The Read Label Tea IS USe Most              Tea use To Kepp warm Body.</p>
        </div>
      </div>   
      <div class = cardo>
        <div class = imageo>
          <img href = "#" src = "images/sp/12.jpeg">
        </div>
        <div class = contento>
          <h3>Good Night</h3>
          <p>In Monson The Amount Of Masquetos Is High ,         Good Night protect from them          So The USe Of It IS High.</p>
        </div>
      </div>   
      
    </div>


    <center><label class="kid">Kids Favirouts</label></center>
    <div class = containero>
      <div class = cardo>
        <div class = imageo>
          <img href = "#" src = "images/sp/13.jpeg">
        </div>
        <div class = contento>
          <h3>Kinder Joy</h3>
          <p>In Children The Kinder Joy Is Most Populer,           It Come With Choclate And Toy                It First Prayority Of Kids.</p>
        </div>
      </div>    
      <div class = cardo>
        <div class = imageo>
          <img href = "#" src = "images/sp/14.jpeg">
        </div>
        <div class = contento>
          <h3>Lays Waffer </h3>
          <p>The Lays Waffer IS Mostly Take For Snake ,           Children Tke Them To Eat             It Come With Many Flavyours But This One Most Popular.</p>
        </div>
      </div>   
      <div class = cardo>
        <div class = imageo>
          <img href = "#" src = "images/sp/15.jpeg">
        </div>
        <div class = contento>
          <h3>Snakers Choclate</h3>
          <p>The Kids Is Atract For Choclate         Snakers Is One Of The Most Popular Choclate In Kids          Kids Like This VErry High.</p>
        </div>
      </div>   
      
    </div>


   
  </body>

</html>
<?php include("pfooter.php"); ?>