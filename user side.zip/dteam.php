<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Our Team</title>
    <link rel="stylesheet" href="css/dstyle.css">
</head>
<body>
    <section class="team-section">
        <h1>Our Team</h1>
        <!-- <p>Lacus vestibulum sed arcu non sit eru racdi odio euismod.</p> -->
        <div class="team-container">
            <?php
            // Define the team members
            $team = [
                [
                    "name" => "Dodiya Dharmik",
                    "role" => "Back-End Devloper",
                    "image" => "images/dimage.png",
                    "social" => [
                        "youtube" => "#",
                        "facebook" => "#",
                        "instagram" => "#",
                        "twitter" => "#"
                    ]
                ],
                [
                    "name" => "Dodeja Prashnat",
                    "role" => "Front-End Devloper",
                    "image" => "images/pimage.png",
                    "social" => [
                        "youtube" => "#",
                        "facebook" => "#",
                        "instagram" => "#",
                        "twitter" => "#"
                    ]
                ],
                [
                    "name" => "Priya Agarval",
                    "role" => "Customer Support",
                    "image" => "images/pic3.jpg",
                    "social" => [
                        "youtube" => "#",
                        "facebook" => "#",
                        "instagram" => "#",
                        "twitter" => "#"
                    ]
                ],
                [
                    "name" => "Shorya Khacher",
                    "role" => "Product-Manager",
                    "image" => "images/pic4.jpg",
                    "social" => [
                        "youtube" => "#",
                        "facebook" => "#",
                        "instagram" => "#",
                        "twitter" => "#"
                    ]
                ]
            ];

            // Generate the HTML for each team member
            foreach ($team as $member) {
                echo "
                <div class='team-member'>
                    <div class='profile-image'>
                        <img src='{$member['image']}' alt='{$member['name']}'>
                    </div>
                    <h3>{$member['name']}</h3>
                    <p>{$member['role']}</p>
                    <div class='social-icons'>";
                foreach ($member['social'] as $platform => $link) {
                    echo "<a href='$link' class='icon-$platform'><i class='fab fa-$platform'></i></a>";
                }
                echo "</div>
                </div>";
            }
            ?>
        </div>
    </section>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</body>
</html>
