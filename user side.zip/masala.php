<?php include("for nav call4.php")?>
<?php include('database.php') ?>
<?php
$products = [
    // ["name" => "Doritos Cheese Nachos", "price" => 43, "image" => "images/f8.jpeg"],
    // ["name" => "Balaji Crunchem Masala Masti Wafers", "price" => 40, "image" => "images/s111.jpeg"],
    // ["name" => "Kurkure Chilli Chatka Crisps  ", "price" => 20, "image" => "images/c121.jpeg"],
    // ["name" => "Lay's Sizzling Hot Potato Chips", "price" => 54, "image" => "images/f11.jpeg"]
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Cards</title>
    <style>
         :root {
    --DTPrimaryColor:#1a3b48;
    --DTSecondaryColor:rgba(9, 46, 119, 0.66);
    --DTBodyBGColor: #ffffff;
    --DTAnimationDuration: 0.4s;
    --DTAnimationTiming: ease-in-out;
    --DTBorderThickness: 3px;
}

.animated-border {
    display: inline-block;
    position: relative;
    padding: 15px 25px;
    color: var(--DTLinkColor);
    text-decoration: none;
    background-color: var(--DTBodyBGColor);
    border-radius: 5px;
    z-index: 1;
    overflow: hidden;
    transition: color var(--DTAnimationDuration) var(--DTAnimationTiming);
}

.animated-border:hover {
    color: var(--DTSecondaryColor);
}

/* Top border - left to right */
.animated-border:before {
    content: '';
    position: absolute;
    background: var(--DTPrimaryColor);
    top: 0;
    left: 0;
    width: 0%;
    height: var(--DTBorderThickness);
    transition: all var(--DTAnimationDuration) var(--DTAnimationTiming);
    opacity: 0;
    transition-delay: 0s;
}

/* Bottom border - right to left */
.animated-border:after {
    content: '';
    position: absolute;
    background: var(--DTSecondaryColor);
    bottom: 0;
    left: 100%; /* Start from the right edge */
    width: 100%; /* Full width */
    height: var(--DTBorderThickness);
    transition: all var(--DTAnimationDuration) var(--DTAnimationTiming);
    opacity: 0;
    transition-delay: calc(var(--DTAnimationDuration) * 0.25);
}

/* Right border - top to bottom */
.animated-border .right-border {
    content: '';
    position: absolute;
    background: var(--DTSecondaryColor);
    top: 0;
    right: 0;
    width: var(--DTBorderThickness);
    height: 0;
    transform-origin: top center;
    transition: all var(--DTAnimationDuration) var(--DTAnimationTiming);
    opacity: 0;
    transition-delay: calc(var(--DTAnimationDuration) * 0.5);
}

/* Left border - bottom to top */
.animated-border .left-border {
    content: '';
    position: absolute;
    background: var(--DTPrimaryColor);
    bottom: 0;
    left: 0;
    width: var(--DTBorderThickness);
    height: 0;
    transform-origin: bottom center;
    transition: all var(--DTAnimationDuration) var(--DTAnimationTiming);
    opacity: 0;
    transition-delay: calc(var(--DTAnimationDuration) * 0.75);
}

/* Hover animation for top border */
.animated-border:hover:before {
    width: 100%;
    opacity: 1;
}

/* Hover animation for bottom border */
.animated-border:hover:after {
    left: 0; /* Move to the left */
    opacity: 1;
}

/* Hover animations for vertical borders */
.animated-border:hover .right-border,
.animated-border:hover .left-border {
    height: 100%;
    opacity: 1;
}

        image{
            height: 500px;
        }
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
           /* display: flex;*/
           
           
            height: 100vh;
            background-color: #f5f5f5;
        }
        .product-container {
            display: flex;
            gap: 20px;
            justify-content: space-evenly;
            padding-top: 50px;
        }

        
    .product-card {
      position: relative;
      width: 300px;
      background: #fff;
      border-radius: 10px;
      overflow: hidden;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
      text-align: center;
      margin-left: -10px;
      padding: 20px;
      transition: transform 0.3s;
   
    }



   
 
       

        .product-card img {
            width: 100%;
            height: 250px;
            border-radius: 8px;
        }
        .product-card h3 {
            margin: 10px 0;
            font-size: 1.2em;
            color:#1a3b48;
        }
        .product-card .price {
            color: #e74c3c;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .product-card .quantity {
            width: 230px;
            margin-bottom: 10px;
            padding: 5px;
            text-align: center;
        }
        .product-card button {
            display: block;
            width: 100%;
            padding: 10px;
            margin: 5px 0;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            transition: background-color 0.3s, color 0.3s;
        }
        .wishlist-button {
            background:rgb(10, 10, 107);
            color: #fff;
        }
        .wishlist-button:hover {
            background:#f10000;
            
        }

       
        .cart-button {
            background:rgb(10, 10, 107);
            color: #fff;
        }
        .cart-button:hover {
            background:#f10000;
        
        }
    </style>
</head>
<body>
    <div class="product-container">
        
<?php

        $sql = "select * from addproduct where category = 'masala'";
        $result = mysqli_query($conn,$sql);

        while($product = mysqli_fetch_assoc($result))
        {

        
?>

        <?php  ?>
            <a href="#" class="animated-border">
    <span class="side-border left-border"></span>
    <span class="side-border right-border"></span>
    


            <div class="product-card">
                <div class="price">₹ <?php echo $product['price'] ?>/-</div>
                <img src="admin/images/addproduct/<?php echo $product['image'] ?>">
                <h3><?php echo$product['iname'] ?></h3>
                <input type="number" class="quantity" value="1" min="1">
                <button class="wishlist-button">Add To Wishlist</button>
                <button class="cart-button" onclick="window.location.href='cartdesc.php?id=<?= $product['id'] ?>'">Add To Cart</button>
            </div>
            </a>
        <?php } ?>
       
    </div>
    
</body>
</html>
<?php include("pfooter.php"); ?>