<?php
session_start();
include("database.php");

if (isset($_GET['payment_id'])) {
    $payment_id = $_GET['payment_id'];
    $username = $_SESSION['username'];

    $sqlcart = mysqli_query($conn, "SELECT * FROM cart WHERE uid = '$username'");

    while ($recart = mysqli_fetch_assoc($sqlcart)) {
        $sql = "INSERT INTO `orders`(`name`,`username`,`image`, `number`, `email`, `method`, `fullAddress`,`p_name`, `qty`, `p_price`, `g_total`,`order_status`, `payment_id`) 
                VALUES ('$recart[name]', '$username', '$recart[image]', '', '', 'online', '', '$recart[name]', '$recart[quantity]', '{$recart['price']}', '', 'confirmed', '$payment_id')";
        mysqli_query($conn, $sql);
    }

    mysqli_query($conn, "DELETE FROM cart WHERE uid = '$username'");

    echo "<script>alert('Payment successful! Order placed.'); window.location.href='orders.php';</script>";
}
?>
