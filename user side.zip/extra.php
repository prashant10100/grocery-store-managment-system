<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clients Reviews</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            padding: 20px;
        }

        .review-card {
            width: 300px;
            margin: 10px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            padding: 20px;
            text-align: center;
        }

        .review-card img {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            margin-bottom: 10px;
        }

        .review-text {
            margin-bottom: 10px;
        }

        .rating {
            display: flex;
            justify-content: center;
            margin-bottom: 10px;
        }

        .star {
            color: #ffc107;
            font-size: 20px;
            margin: 0 2px;
        }

        .name {
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="review-card">
            <img src="https://via.placeholder.com/100x100" alt="Roshni Shah">
            <div class="review-text">
                The Company Itself is a very Successful
                company. And let their pleasures be
                theirs and let them not leave the open door
                with.
            </div>
        </div>
    </div>
</body>
</html> 