<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image with Border and Text</title>
    <style>
        .container {
            width: 300px; /* Adjust as needed */
            background-color: white;
            padding: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
            font-family: Arial, sans-serif;
            border-radius: 10px;
        }
        .image-container {
            background-color: #fff;
            padding-bottom: 20px;
        }
        img {
            width: 100%;
            display: block;
            border-radius: 10px 10px 0 0;
        }
        .text-container {
            padding: 10px;
        }
        .text-container h2 {
            margin: 5px 0;
            font-size: 18px;
            font-weight: bold;
        }
        .text-container p {
            margin: 0;
            font-size: 14px;
            color: #555;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="image-container">
        <img src="images/1.jpeg">
    </div>
    <div class="text-container">
        <h2>Filan Fisteku</h2>
        <p>Architect Manager</p>
    </div>
</div>

</body>
</html>
