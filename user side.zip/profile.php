<?php
session_start();
include("database.php");

if(!$conn) {
    echo "Database connection failed.";
}

if(!$_SESSION["username"]) {
    header("location:login.php");
}

$user = $_SESSION["username"];
$query = "SELECT * FROM newregistration WHERE username='$_SESSION[username]'";
$exquery = mysqli_query($conn, $query);
$result = mysqli_fetch_assoc($exquery);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile UI</title>
    <link rel="stylesheet" href="profile.css">
</head>
<body>
    <div class="main-container">
        <div class="sidebar">
            <h3>Profile</h3>
            <div class="avatar">
                <center>
                    <img src="admin/images/Register User/<?php echo $result['img']; ?>" alt="Profile Picture">
                    <h2><?php echo $result["name"]; ?><br><span></span></h2>
                </center>
            </div>
            <ul>
                <li><a href="profile.php">My Accounts</a></li>
                <li><a href="myorder.php">My Orders</a></li>
                <li><a href="wish2.php">My Wishlist</a></li>
                <!-- <li><a href="#">Payment</a></li> -->
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>

        <div class="content-container">
            <div class="sub-container">
                <h3>Personal Information</h3>
                <a href="updateuser.php?id=<?php echo $result['id']; ?>">
                    <button class="edit-btn">Change Profile Information</button>
                </a>
                <div class="info-form">
                    <label>Name</label>
                    <input type="text" name="name" value="<?php echo $result['name']; ?>" readonly>

                    <label>Date of Birth</label>
                    <input type="date" name="date" value="<?php echo $result['dob']; ?>" readonly>

                    <label>Gender</label>
                    <div class="gender">
                        <label><input type="radio" name="gender" value="Male" <?php echo ($result["g"] === 'Male') ? 'checked' : ''; ?> readonly disabled> Male</label>
                        <label><input type="radio" name="gender" value="Female" <?php echo ($result["g"] === 'Female') ? 'checked' : ''; ?> readonly disabled> Female</label>
                    </div>

                    <label>Phone Number</label>
                    <input type="text" name="pno" value="<?php echo $result['mno']; ?>" readonly>

                    <label>Email</label>
                    <input type="email" name="email" value="<?php echo $result['email']; ?>" readonly>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
