<?php 
include ("for nav call4.php");
include("database.php");
$sql = "select * from category";
$result = mysqli_query($conn, $sql);

if(!$_SESSION['username'])
{
    ?>
        <script>
            location.href = 'login.php';
        </script>
    <?php
}
?>
<html>

<head>
    <style>
   
 
   

        .stext,
        .ourtext,
        .exptext {
            font-family: lato, sans-serif;
            line-height: 2;
            font-size: 30px;
            font-weight: 600;
            color: #251D34;
            margin-bottom: 10px;
        }

        .oursback {
            background-color: rgba(255, 255, 255, 0.411);
            /* margin: -120px; */
            /* padding-top: 100px; */

            /* background-color: aqua; */
            /* width: 100%; */
        }
                                                
        .imageinconteiner:hover {
            border: 4px solid transparent;
            /* transform: scale(1); */
            /* transform-origin: 40% 20%; */
            /* transform: translateZ(10px); */
        }

        .oursconteiner {
            padding: 7px;
            margin-left: 8px;
            max-width: fit-content;
            /* background-color: aqua; */
            border-radius: 5px;
            margin-bottom: 10px;
            display: flex;
            justify-content: space-around;
            gap: 250px;
            flex-wrap: wrap;
            text-decoration: none;
        }

        .imageinconteiner {
            width: 18vw;
            height: 30vh;
            margin-bottom: 5px;
            border-radius: 10px;

        }

        .gallerymain {
            display: flex;
            justify-content: center;
            height: fit-content;
        }

        .ourtext {
            /* margin: 600px; */
            font-size: 45px;
            text-decoration: none;
        }
        a{
            text-decoration: none;
            color: black;
        }
    </style>
</head>

<body><br>
    <div class="oursback">
        <center><label class="ourtext">All Categories</label></center><br>
        

            <div class="gallerymain">
                <div class="1">
                    <div class="oursconteiner">
                    <?php
                    while ($row = mysqli_fetch_assoc($result)) {
                    ?>
                    <div>   
                    <a href="productsubpage.php?id=<?php echo $row['id']; ?>">
                        <img src="Admin\images\category\<?php echo $row['image']; ?>" class="imageinconteiner"></img><br>

                        <label class="ourscontainer"><?php echo $row['name']; ?></label><br>
                        </a>    
                    </div>
                        
                        <?php
                        }
                            ?>
                    </div>
                    
                </div>
                <!-- <div class="oursconteiner">
                    <a href="choclate.php"><img src="images/choclatecat.jpeg" class="imageinconteiner"></image></a><br>
                    <label class="ourscakename">Choclates Products</label><br>

                </div>
                <div class="oursconteiner">
                    <a href="drinks.php"> <img src="images/drinkscat.jpeg" class="imageinconteiner"></image></a><br>
                    <label class="ourscakename">Drinks Products</label><br>

                </div>
                </div>
                <div class="2">
                    <div class="oursconteiner">
                        <a href="fritsandvegi.php"> <img src="images/fruitsandvegicat.jpeg" class="imageinconteiner"></image></a><br>
                        <label class="ourscakename">Fruits and Vegitable</label><br>

                    </div>

                    <div class="oursconteiner">
                        <a href="dryfruits.php"><img src="images/dryfruitscat.jpeg" class="imageinconteiner"></image></a><br>
                        <label class="ourscakename">Dry-Fruits Products</label><br>

                    </div>

                    <div class="oursconteiner">
                        <a href="meegi.php"><img src="images/meegicat.jpeg" class="imageinconteiner"></image></a><br>
                        <label class="ourscakename">Meggi And Nudles</label><br>

                    </div>
                </div>
                <div class="3">
                    <div class="oursconteiner">
                        <a href="snacks.php"><img src="images/snackscat.jpeg" class="imageinconteiner"></image></a><br>
                        <label class="ourscakename">Snacks Products</label><br>

                    </div>

                    <div class="oursconteiner">
                        <a href="milk.php"> <img src="images/milkcat.jpeg" class="imageinconteiner"></image></a><br>
                        <label class="ourscakename">Milk And Related Products</label><br>

                    </div>


                    <div class="oursconteiner">
                        <a href="radytoeat.php"> <img src="images/bis1.jpeg" class="imageinconteiner"></image></a><br>
                        <label class="ourscakename">Biscuits Products</label><br>

                    </div>
                </div>

            </div> -->

            <br>
    </div>


</body>

</html>
<?php include("pfooter.php"); ?>