<?php

include("database.php");
$mname = $mlname = $mmno = $mdob = $mg = $memail = $musername = $mpassword = $mcity = "";
$error = 0;
$name = $mno = $dob = $g = $email = $username = $city = "";
$id = $_GET["id"];

$sql = "select * from newregistration where id = $id";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);

if (isset($_POST["update"])) {
    $files = $_FILES["file"];
    $img = $_FILES["file"]["name"];
    $path = "C:\Users\dell\Desktop\MY PROJECT\Admin\images\Register User/" . $_FILES["file"]["name"];
    $name = $_POST["name"];
    $mno = $_POST["mno"];
    $dob = $_POST["dob"];
    $g = $_POST["g"];
    $email = $_POST["email"];
    $username = $_POST["username"];
    $password = $_POST["password"];
    $city = $_POST["city"];

    if(!empty($img)){
        move_uploaded_file($_FILES["file"]["tmp_name"], $path);
        $img= $_FILES["file"]["name"];
    }
    else{
        $img=$row['img'];
    }

    
    $sql = "update newregistration set img='$img',name = '$name',mno=$mno,dob = '$dob',g = '$g',email = '$email',username = '$username',password = '$password',city = '$city' where id = $id";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        ?>
        <script>
            alert("User Updated Successfully !!");
            location.href="profile.php";
        </script>
        <?php 
    } else {
        echo "<div class='success' id='u'>";
        echo "Registration Unsuccessfull" . "<br>";
        echo "<input type='button' name='unsuccessok' value='OK' id='sok' class='unsuccessok'>";
        echo "</div>";
    }

}
?>

<html>

<head>
    <title>Update Register User</title>
    <link rel="stylesheet" href="css/updatereguser.css">
    
<link rel="stylesheet" href="../fontawesome-free-6.7.2-web/css/fontawesome.min.css">
  <link rel="stylesheet" href="../fontawesome-free-6.7.2-web/css/all.min.css">

</head>

<body>
    <form method="post" enctype="multipart/form-data">
        <center>
       
            <div class="mainform">
            <a href="userprofile.php"><i class="fa-solid fa-arrow-left"></i></a><br><br>
                <img src="admin/images/Register User/<?php echo $row['img']; ?>" alt="" class="reguserimage"><br>

                <input type="file" name="file"><br><br>

                <label class="label">ID</label><br>
                <input type="text" name="name" placeholder="Enter your Name" class="reginput"
                    value="<?php echo $row["id"]; ?>" readonly><br><br>

                <label class="label">Name<b class="red">*</b> </label><br>
                <input type="text" name="name" placeholder="Enter your Name" class="reginput"
                    value="<?php echo $row["name"]; ?>">
                <br><label class="red"><?php echo $mname; ?></label>
                <br>

                <label class="label">Mobile No.<b class="red">*</b> </label><br>
                <input type="text" name="mno" placeholder="Enter your Mobile Number" class="reginput"
                    value="<?php echo $row["mno"]; ?>" minlength="10" maxlength="10">
                <br><label class="red"><?php echo $mmno; ?></label>
                <br>

                <label class="label">Date of Birth<b class="red">*</b> </label><br>
                <input type="date" name="dob" class="reginput" value="<?php echo $row["dob"]; ?>">
                <br><label class="red"><?php echo $mdob; ?></label>
                <br>

                <label class="label">City<b class="red">*</b> </label><br>
                <input type="text" name="city" placeholder="Enter your City" class="reginput"
                    value="<?php echo $row["city"]; ?>">
                <br><label class="red"><?php echo $mcity; ?></label><br>

                <label class="label">Gender<b class="red">*</b> </label><br>
                <input type="radio" name="g" class="gender" value="Male" checked>Male
                <input type="radio" name="g" class="gender" value="Female">Female
                <br><label class="red"><?php echo $mg; ?></label>
                <br>




                <label class="label">E-mail<b class="red">*</b> </label><br>
                <input type="text" name="email" placeholder="Ex - abc123@gmail.com" class="reginput"
                    value="<?php echo $row["email"]; ?>">
                <br><label class="red"><?php echo $memail; ?></label>
                <br>

                <label class="label">Username<b class="red">*</b></label><br>
                <input type="text" name="username" placeholder="Enter your Username" class="reginput"
                    value="<?php echo $row["username"]; ?>"readonly>
                <br><label class="red"><?php echo $musername; ?></label>
                <br>

                <label class="label">Password<b class="red">*</b> </label><br>
                <input type="password" name="password" id="password" placeholder="Enter your Password" class="reginput"
                    value="<?php echo $row["password"]; ?>"><a id="show" class="show">Show</a>
                <br><label class="red"><?php echo $mpassword; ?></label>
                <br>


                <center><input type="submit" name="update" value="Update" id="sub" class="submit"><br></center>

            </div>
        </center>
    </form>
</body>

</html>
<script>
    let show = document.getElementById("show")
    let password = document.getElementById("password")
    let reginput = document.getElementById("reginput")

    show.onclick = function () {
        if (password.type == "password") {
            password.type = "text";
            show.text = "Hide";
        }
        else {
            password.type = "password";
            show.text = "Show";
        }
    }
    let sok = document.getElementById("sok");
    let successmes = document.querySelector(".success");
    sok.onclick = function () {
        successmes.style.display = "none";
    }   
</script>