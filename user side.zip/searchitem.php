<?php

include "for nav call4.php";

include("database.php"); 

error_reporting(0);

// Database Connection

$length=0;

$search=null;

if (isset($_GET['search_input']))
 {


    $search_input = mysqli_real_escape_string($conn, $_GET['search_input']); 

    $query = "SELECT * FROM category WHERE name LIKE '%$search_input%'";

    $exe_query = mysqli_query($conn,$query);
    $length = mysqli_num_rows($exe_query);

    


}


?>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="css/search_page.css">
</head>

<body>
    <br>
    <label class='searchresulttext'>Search Results for:<?php echo htmlspecialchars($search_input) ?></label>
    <br><br>
    <center>

        <section class="products">

            <div class="box-container">


                <?php
                if (isset($_GET['search_input'])) {

                    $s="SELECT * FROM category WHERE name LIKE '%$search_input%'";
                    $search_query = mysqli_query($conn, $s);

                    if (mysqli_num_rows($search_query) > 0) {

                        while ($fetch_products = mysqli_fetch_assoc($search_query)) {

                            $q="select * from addproduct where category = '$fetch_products[name]'";
                            $sqlcategoryimage = mysqli_query($conn, $q);
                            while ($rcategory = mysqli_fetch_assoc($sqlcategoryimage)) {

                                ?>

                                <form action="" class="box" method="POST">

                                    <div class="productflex">

                                        <div>

                                          

                                            <a href="cakedesc.php?id=<?php echo $rcategory['id']; ?>">

                                                <img src="Admin/images/addproduct/<?php echo $rcategory['image']; ?>" alt=""
                                                    class="searchpageimage">
                                            </a>
                                        </div>
                                        <div class="pnameprice">

                                            <div class="name"><?php echo $fetch_products['name']; ?></div>

                                            <input type="hidden" name="pid" value="<?php $rcategory['id']; ?>">
                                            <input type="hidden" name="p_name" value="<?php $rcategory['iname']; ?>">
                                            <input type="hidden" name="p_price" value="<?php $rcategory['price']; ?>">
                                            <input type="hidden" name="p_image" value="<?php $rcategory['image']; ?>">

                                            <?php



                                            ?>

                                            <a href="cakedesc.php?id=<?php echo $rcategory['id']; ?>" class="redirecttocakedesc">
                                                <label class="searchcakename"><?php echo $rcategory['iname']; ?></label><br>
                                            </a>
                                            <!-- <label class="searchcakeratingstars">&#9733;&#9733;&#9733;&#9733;&#9733;</label><br> -->
                                            <label class="price">₹<?php echo $rcategory['price']; ?>/-</label> <br>
                                            
                                            <br><br>

                                            <?php
                                            $resultcartdescre = mysqli_query($conn, "select * from addproduct where category='$fetch_products[name]'");
                                            $rcartdescre = mysqli_fetch_assoc($resultcartdescre);
                                            ?>
                                            <a href="cartdesc.php?id=<?php echo $rcartdescre['id']; ?>" class="cakesubaddtocart">Add to
                                                cart</a>
                                        </div>
                                    </div>
                                </form>

                                <?php
                                
                            }
                            
                        }
                    } else {
                        echo "<p>No results found.</p><br><br>";
                    }
                } else {
                    echo "<p>Please enter a search term.</p>";
                }
                ?>
            </div>
        </section>
    </center>
</body>

</html>