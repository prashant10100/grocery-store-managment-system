<?php
session_start();
include("database.php");


 $u_id=$_SESSION['username'];

echo $id = $_GET["id"];
//  if (isset($_POST["add_to_cart"])) {

// if (!$u_id) {
//   header("location:loginr.php");
// } else {
  $quantity = 1;

  $sqlcartse = "select * from addproduct where iname = '$id'";
  $resultcartse = mysqli_query($conn, $sqlcartse);
  $rcartse = mysqli_fetch_assoc($resultcartse);

  $sqlunique = "select * from cart where name = '$rcartse[iname]' and uid='$u_id' ";
  $resultunique = mysqli_query($conn, $sqlunique);
  $runique = mysqli_num_rows($resultunique);
  if ($runique >= 1) {
    ?>
    <script>
      alert("This Product is Already added !!");
      location.href = "cart.php?categoryname=<?php echo $rcartse['category']; ?>";
    </script>
    <?php
  } else {

    $query = "insert into cart values(id,'$u_id','$rcartse[iname]',$rcartse[price],'$rcartse[image]',$quantity)";
    $result = mysqli_query($conn, $query);
    if ($result) {
      ?>
      <script>
        alert("Product was added to cart Successfully !!");
        location.href = "cart.php?categoryname=<?php echo $rcartse['category']; ?>";
      </script>
      <?php

    } else {
      echo "Product not added to cart Unsuccessfull" . "<br>";

      echo "<div class='unsuccess' id='u'>";
      echo "Product not added to cart Unsuccessfull" . "<br>";
      echo "<input type='button' name='unsuccessok' value='OK' class='unsuccessok'>";
      echo "</div>";

    }
  }
//}

// }
?>