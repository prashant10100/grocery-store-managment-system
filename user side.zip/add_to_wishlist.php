<?php
// Include the database connection
include("database.php");

// Check if the form is submitted and required data is received
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve the product data from the POST request
    $product_name = $_POST['product_name'];
    $price = $_POST['price'];
    $image = $_POST['image'];

    // Prepare the SQL query to insert into the wishlist table
    $sql = "INSERT INTO wishlist VALUES (id,1,'$product_name',$price,'$image')";
    $result = mysqli_query($conn,$sql);
    // // Prepare the statement
    // if ($stmt = $conn->prepare($sql)) {
    //     // Bind parameters to the SQL query
    //     $stmt->bind_param("sds", '$product_name', $price, '$image');

    //     // Execute the query
    //     if ($stmt->execute()) {
    //         echo "<script>alert('Product added to wishlist successfully');</script>";
    //     } else {
    //         echo "<script>alert('Failed to add product to wishlist');</script>";
    //     }

    //     // Close the prepared statement
    //     $stmt->close();
    // } else {
    //     echo "<script>alert('Database error');</script>";
    // }
}

// Close the connection
$conn->close();

// Redirect back to the product page or wishlist page
header("Location: wishlist.php");
exit();
?>
