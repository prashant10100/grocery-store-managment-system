<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	<style>

body {
			width: 100%;
			height: 5vh;
			text-align: center;
			font-weight: bold;
			background-position: center;
			background-size: cover;
			margin-bottom: 50%;
			background-repeat: no-repeat;
			background-position: center;
		}


nav {
			background-position: center;
			background-repeat: no-repeat;
			width: 200%;
			height: 100px;
			background-color: black;
			align-items: left;
			display: flex;
			align-items: center;
			justify-content: space-between;
            margin-right: -100px;
			left: -1350px;
			margin-left: -100px;    /*logo chagne thay size*/
			background-size: 80px;
			background-image: url("4.png");
			position: fixed;
			top: 0px;
		}

		.menu {
			width: 65%;
			display: flex;
			justify-content: right;
			list-style: none;
			width: 100%;
			justify-content: center;
			align-items: center;
			min-height: 100vh;
			font-size: 1.1em;
			color: #fff;
			text-decoration: none;
			font-weight: 500;
			margin-left: 650px;
		}



		.search {
			display: flex;
			margin-left: -0px;
			margin-top: 0px;
			padding: -20px;
		}

		.search form {
			display: flex;
			margin: -20px;
			margin-right: 200px;

		}

		.search input {
			padding: -20px;
			border: 1px solid #ddd;
			outline: none;
			border-radius: 20px;
			margin-right: 20px;
			font-size: 16px;

		}

		.search input:hover {
			border: 1px solid;
		}

		nav li {
			padding: 15px;
		}



		.icon {
			width: 50px;
			color: white;
			margin: 10px;
			margin-left: 10px;
            gap:-100px;
			padding-right: 50px;
			margin-right: 40px;
			font-size: 25px;
		}

		.icon2 {
			color: white;
			margin: 10px;
			margin-left: -50px;
			padding-right: 5px;
			font-size: 25px;
		}

		.icon3 {
			color: white;
			font-size: 25px;
			margin-right: 25px;
			margin: 10px;

		}

		.icon4 {
			color: white;
			font-size: 25px;
			margin: 10px;
			margin-right: -400px;

		}


		* {
  margin: 0;
  padding: 0;
}

html,
css {
  width: 100%;
  height: 100%;
}

.position {
  margin: 100px;
}

#workarea {
  position: absolute;
  width: 100%;
  height: 100%;
  font-family: Georgia, 'Times New Roman', Times, serif;
}

#personal {
  color:white;
  text-decoration:none;
  position:absolute;
  bottom:15px;
  right: 2%;
}
/*    start code for the actual button:         */


/*   
    Spot is the span on the inside of the href that
    fills the parent and makes the hover and link work
    for the entire div
*/

.spot {
  position: absolute;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
}
/*
    This is the outer svg wrapper that the SVG itself will 
    fill. Multiple svg-wrapper classes can be put side by side.
*/

.svg-wrapper {
  margin-top: 0;
  position: relative;
  width: 150px;
  /*make sure to use same height/width as in the html*/
  height: 40px;
  display: inline-block;
  border-radius: 3px;
  margin-left: 5px;
  left: -20px;
  margin-right: 5px
}
/*
  This is where we define the fill, color, thickness,
  and stroke pattern of the SVG when there is no hover.
  The dasharray and offset together define the line position
  under the words. Here's also where the transition speed is set.
*/

#shape {
  stroke-width: 6px;
  fill: transparent;
  stroke:rgb(233, 235, 236);
  stroke-dasharray: 85 400;
  stroke-dashoffset: -220;
  transition: 1s all ease;
}
/* 
    Pushing the text up into the SVG. Without this the
    text would be below the div's.
*/

#text {
  margin-top: -35px;
  text-align: center;
}

#text a {
  color: white;
  text-decoration: none;
  font-weight: 100;
  font-size: 1.1em;
}
/* 
    Changing the shape on hover. I change the color of the stroke,
make it thinner, then set it to again wrap around the entire parent element.
*/

.svg-wrapper:hover #shape {
  stroke-dasharray: 50 0;
  stroke-width: 3px;
  stroke-dashoffset: 0;
  stroke:white;
}










	</style>
</head>
<body>
<div id="workarea">
<div class="position">
<nav>
	<ul class="menu">
    <div class="svg-wrapper">
    <svg height="40" width="150" xmlns="http://www.w3.org/2000/svg">
    <rect id="shape" height="40" width="150" />
        <div id="text">
        <a href="fhome.php"><span class="spot"></span>Home</a>
    </div>
</svg>
</div>
<div class="svg-wrapper">
    <svg height="40" width="150" xmlns="http://www.w3.org/2000/svg">
    <rect id="shape" height="40" width="150" />
        <div id="text">
        <a href="shop.php"><span class="spot"></span>Shops</a>
    </div>
</svg>
</div>
<div class="svg-wrapper">
    <svg height="40" width="150" xmlns="http://www.w3.org/2000/svg">
    <rect id="shape" height="40" width="150" />
        <div id="text">
        <a href="extra2.php"><span class="spot"></span>Customer Review</a>
    </div>
</svg>
</div>
<div class="svg-wrapper">
    <svg height="40" width="150" xmlns="http://www.w3.org/2000/svg">
    <rect id="shape" height="40" width="150" />
        <div id="text">
        <a href="contact.php"><span class="spot"></span>Contact US</a>
    </div>
</svg>
</div>
<div class="svg-wrapper">
    <svg height="40" width="150" xmlns="http://www.w3.org/2000/svg">
    <rect id="shape" height="40" width="150" />
        <div id="text">
        <a href="rabout.php"><span class="spot"></span>About Us</a>
    </div>
</svg>
</div>
<div class="svg-wrapper">
    <svg height="40" width="150" xmlns="http://www.w3.org/2000/svg">
    <rect id="shape" height="40" width="150" />
        <div id="text">
        <a href="login.php"><span class="spot"></span>Login</a>
    </div>
</svg>
</div>

<div class="search">
			<form method="post">
				<input type="text" placeholder="Search...">

				<div class="icon">
					<i class="fa-solid fa-magnifying-glass"></i>
				</div>

				<div class="icon2">
					<i class="fa-regular fa-heart"></i>
				</div>

				<div class="icon3">
					<i class="fa-solid fa-cart-shopping"></i>
				</div>

				<div class="icon4">
					<i class="fa-solid fa-user"></i>
				</div>
			</form>
		</div>
		</ul>
		</div>
		</div>
	</nav>
</div>
</div>
</body>
</html>