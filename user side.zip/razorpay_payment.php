<?php
session_start();
require('razorpay-php/Razorpay.php');

use Razorpay\Api\Api;

$api_key = "YOUR_RAZORPAY_KEY";
$api_secret = "YOUR_RAZORPAY_SECRET";
$api = new Api($api_key, $api_secret);

$orderData = [
    'receipt' => rand(1000, 9999),
    'amount' => $_GET['amount'] * 100, // Convert to paisa
    'currency' => 'INR',
    'payment_capture' => 1
];

$order = $api->order->create($orderData);

$_SESSION['order_id'] = $order['id'];

?>

<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
    var options = {
        "key": "<?php echo $api_key; ?>",
        "amount": "<?php echo $_GET['amount'] * 100; ?>",
        "currency": "INR",
        "name": "<?php echo $_GET['name']; ?>",
        "description": "Order Payment",
        "image": "your-logo.png",
        "order_id": "<?php echo $order['id']; ?>",
        "handler": function(response) {
            window.location.href = "payment_success.php?payment_id=" + response.razorpay_payment_id;
        },
        "prefill": {
            "name": "<?php echo $_GET['name']; ?>",
            "email": "<?php echo $_GET['email']; ?>",
            "contact": "<?php echo $_GET['contact']; ?>"
        },
        "theme": {
            "color": "#3399cc"
        }
    };
    var rzp = new Razorpay(options);
    rzp.open();
</script>
