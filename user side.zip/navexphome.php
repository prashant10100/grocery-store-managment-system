<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/navdemo.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Navbar Example</title>
</head>
<body>
    <header class="navbar">
        <div class="logo">
            <img src="4.png" alt="Logo" />
        </div>
        <div id="workarea">
<div class="position">


<nav>
	<ul class="menu">
    <div class="svg-wrapper">
    <svg height="40" width="150" xmlns="http://www.w3.org/2000/svg">
    <rect id="shape" height="40" width="150" />
        <div id="text">
        <a href="fhome.php"><span class="spot"></span>Home</a>
    </div>
</svg>
</div>
<div class="svg-wrapper">
    <svg height="40" width="150" xmlns="http://www.w3.org/2000/svg">
    <rect id="shape" height="40" width="150" />
        <div id="text">
        <a href="shop.php"><span class="spot"></span>Shops</a>
    </div>
</svg>
</div>
<div class="svg-wrapper">
    <svg height="40" width="150" xmlns="http://www.w3.org/2000/svg">
    <rect id="shape" height="40" width="150" />
        <div id="text">
        <a href="extra2.php"><span class="spot"></span>Customer Review</a>
    </div>
</svg>
</div>
<div class="svg-wrapper">
    <svg height="40" width="150" xmlns="http://www.w3.org/2000/svg">
    <rect id="shape" height="40" width="150" />
        <div id="text">
        <a href="contact.php"><span class="spot"></span>Contact US</a>
    </div>
</svg>
</div>
<div class="svg-wrapper">
    <svg height="40" width="150" xmlns="http://www.w3.org/2000/svg">
    <rect id="shape" height="40" width="150" />
        <div id="text">
        <a href="rabout.php"><span class="spot"></span>About Us</a>
    </div>
</svg>
</div>
<div class="svg-wrapper">
    <svg height="40" width="150" xmlns="http://www.w3.org/2000/svg">
    <rect id="shape" height="40" width="150" />
        <div id="text">
        <a href="login.php"><span class="spot"></span>Login</a>
    </div>
</svg>
</div>
        <div class="search-container">
            <input type="text" placeholder="Search..." class="search-bar">
        </div>
        <!-- <div class="searchicon">
            <a href="#" class="icon"><img src="icon-1.jpeg" alt="Search"></a>
            </div> -->

            <div class="icon1">
					<i class="fa-solid fa-magnifying-glass"></i>
				</div>

				<div class="icon2">
					<i class="fa-regular fa-heart"></i>
				</div>

				<div class="icon3">
					<i class="fa-solid fa-cart-shopping"></i>
				</div>

				<div class="icon4">
					<i class="fa-solid fa-user"></i>
				</div>

                </ul>
		</nav>
		</div>
		</div>
    </header>
</body>
</html>