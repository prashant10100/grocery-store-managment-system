<?php
session_start();
include("database.php");
$id = $_GET['id'];

$prores = mysqli_query($conn, "select * from addproduct where id = $id");
$pror = mysqli_fetch_assoc($prores);

$wishmultiple = mysqli_query($conn, "select * from wishlist where uid = '$_SESSION[username]' and name = '$pror[iname]'");
echo $wishmulcount = mysqli_num_rows($wishmultiple);
if ($wishmulcount == 0) {
    $wishins = mysqli_query($conn, "insert into wishlist values(id,'$_SESSION[username]','$pror[iname]','$pror[price]','$pror[image]')");

    if ($wishins) {
        
?>
       <script>
            alert("Product Added Successfully !!");
            location.href = "wish2.php";
        </script>
    <?php
    } else {
        echo "non";
    }
} else {
    ?>
    <script>
        alert("Product is already Added !!");
        location.href = "wish2.php";
    </script>
<?php
}
?>
<!-- 9558801902 -->