<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Our Team</title>
    <link rel="stylesheet" href="fstyle.css">
</head>
<body>
    <section class="team-section">
        <h1>Our Team</h1>
        <p>Lacus vestibulum sed arcu non sit eru racdi odio euismod.</p>
        <div class="team-container">
            <?php
            // Define the team members
            $team = [
                [
                    "name" => "Ethelyn Hilaire",
                    "role" => "CEO",
                    "image" => "dimage.png",
                    "social" => [
                        "facebook" => "#",
                        "twitter" => "#",
                        "linkedin" => "#",
                        "youtube" => "#"
                    ]
                ],
                [
                    "name" => "Timmy Bard",
                    "role" => "Product Manager",
                    "image" => "pimage.png",
                    "social" => [
                        "instagram" => "#",
                        "twitter" => "#",
                        "pinterest" => "#",
                        "linkedin" => "#"
                    ]
                ],
                [
                    "name" => "Willie Hagel",
                    "role" => "Customer Support",
                    "image" => "pic3.jpg",
                    "social" => [
                        "facebook" => "#",
                        "instagram" => "#",
                        "youtube" => "#",
                        "linkedin" => "#"
                    ]
                ],
                [
                    "name" => "Soraya Rolston",
                    "role" => "Manager",
                    "image" => "pic4.jpg",
                    "social" => [
                        "twitter" => "#",
                        "pinterest" => "#",
                        "facebook" => "#",
                        "youtube" => "#"
                    ]
                ]
            ];

            // Display team members
            foreach ($team as $member) {
                echo "
                <div class='team-member'>
                    <div class='profile-image'>
                        <img src='{$member['image']}' alt='{$member['name']}'>
                    </div>
                    <h3>{$member['name']}</h3>
                    <p>{$member['role']}</p>
                    <div class='social-icons'>";
                foreach ($member['social'] as $platform => $link) {
                    echo "<a href='$link'><i class='fab fa-$platform'></i></a>";
                }
                echo "</div>
                </div>";
            }
            ?>
        </div>
    </section>
    <!-- FontAwesome Icons -->
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</body>
</html>
