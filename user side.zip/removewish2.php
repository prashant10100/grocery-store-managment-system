<?php
include("database.php");
    echo $id = $_GET['id'];

    $wishres = mysqli_query($conn,"delete from wishlist where id = $id");
    if($wishres)
    {
        ?>
        <script>
            alert("Product removed from wishlist Successfully !!");
            location.href = "wish2.php";
        </script>
        <?php
    }
?>