<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Place Your Order</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f8f8;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 40px;
          
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
            background-color:rgb(94, 97, 99);
            padding: 15px;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-bottom: 5px;
            font-weight: bold;
        }
        input, select {
            margin-bottom: 15px;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
            width: 100%;
        }
        input:focus, select:focus {
            border-color: #56b4ef;
            outline: none;
        }
        .btn {
            background-color: #28a745;
            color: #fff;
            border: none;
            padding: 12px;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .btn:hover {
            background-color:rgb(64, 65, 66);
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Place Your Order</h1>
        <form action="submit_order.php" method="POST">
            <label for="name">Your Name:</label>
            <input type="text" id="name" name="name" placeholder="Enter your name" required>

            <label for="number">Your Number:</label>
            <input type="text" id="number" name="number" placeholder="Enter your number" required>

            <label for="email">Your Email:</label>
            <input type="email" id="email" name="email" placeholder="Enter your email" required>

            <label for="payment">Payment Method:</label>
            <select id="payment" name="payment">
                <option value="cod">Cash on Delivery</option>
                <option value="credit_card">Credit Card</option>
                <option value="paypal">PayPal</option>
            </select>

            <label for="address1">Address Line 01:</label>
            <input type="text" id="address1" name="address1" placeholder="e.g., Flat Number" required>

            <label for="address2">Address Line 02:</label>
            <input type="text" id="address2" name="address2" placeholder="e.g., Street Name" required>

            <label for="city">City:</label>
            <input type="text" id="city" name="city" placeholder="e.g., Botad" required>

            <label for="state">State:</label>
            <input type="text" id="state" name="state" placeholder="e.g., Gujarat" required>

            <label for="country">Country:</label>
            <input type="text" id="country" name="country" placeholder="e.g., India" required>

            <label for="pin">Pin Code:</label>
            <input type="text" id="pin" name="pin" placeholder="e.g., 364710" required>

            <button type="submit" class="btn">Place Order</button>
        </form>
    </div>
</body>
</html>
