<?php
echo " this is a page";

?>